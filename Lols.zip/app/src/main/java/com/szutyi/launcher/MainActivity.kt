package com.szutyi.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

/**
 * SzutyiUI Launcher
 *
 * A real Android home-screen replacement:
 *  - registers for the HOME intent, so Android offers it as a launcher choice
 *  - reads the real list of installed apps via PackageManager
 *  - home screen = clock + dock; swipe up = full searchable app drawer
 *  - long-press an icon for App info / Uninstall
 *
 * launchMode="singleTask" means pressing the physical/gesture Home button
 * again re-delivers the intent to onNewIntent() rather than recreating the
 * activity - we use that to snap back to the home screen and close the drawer.
 */
class MainActivity : ComponentActivity() {

    // bumped every time the user presses Home again while already in the launcher
    private val homeSignal = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SzutyiLauncherTheme {
                LauncherRoot(homeSignal = homeSignal.value)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        homeSignal.value++
    }
}

@Composable
fun LauncherRoot(homeSignal: Int) {
    val context = LocalContext.current

    var drawerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var contextMenuApp by remember { mutableStateOf<AppInfo?>(null) }

    // re-scan on first composition; cheap enough for a home screen list
    val allApps = remember { AppRepository.getLaunchableApps(context) }
    val dockApps = remember(allApps) { allApps.take(5) }

    // pressing Home again while already here -> snap back, close drawer/search
    LaunchedEffect(homeSignal) {
        drawerOpen = false
        query = ""
    }

    // physical/gesture back closes the drawer instead of leaving the launcher
    BackHandler(enabled = drawerOpen) { drawerOpen = false }

    val drawerOffset by animateDpAsState(
        targetValue = if (drawerOpen) 0.dp else 1000.dp,
        animationSpec = tween(320),
        label = "drawerOffset"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF2A1F4D), Color(0xFF14233A), Color(0xFF0D0916))
                )
            )
    ) {
        // ---------------- HOME LAYER ----------------
        Column(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount < -14) drawerOpen = true
                    }
                }
        ) {
            Spacer(Modifier.height(72.dp))
            ClockBlock()
            Spacer(Modifier.weight(1f))
            Dock(
                apps = dockApps,
                onTap = { AppRepository.launch(context, it) },
                onLongPress = { contextMenuApp = it }
            )
            Spacer(Modifier.height(22.dp))
            SwipeHandle()
            Spacer(Modifier.height(14.dp))
        }

        // ---------------- APP DRAWER LAYER ----------------
        Column(
            modifier = Modifier
                .fillMaxSize()
                .offset { IntOffset(0, drawerOffset.toPx().roundToInt()) }
                .background(Color(0xE60A0712))
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount > 14) drawerOpen = false
                    }
                }
        ) {
            Spacer(Modifier.height(56.dp))
            SearchField(value = query, onChange = { query = it })
            Spacer(Modifier.height(18.dp))
            val filtered = remember(allApps, query) {
                if (query.isBlank()) allApps
                else allApps.filter { it.label.contains(query, ignoreCase = true) }
            }
            AppGrid(
                apps = filtered,
                onTap = { AppRepository.launch(context, it) },
                onLongPress = { contextMenuApp = it },
                modifier = Modifier.weight(1f)
            )
        }
    }

    contextMenuApp?.let { app ->
        AppContextMenu(
            app = app,
            onDismiss = { contextMenuApp = null },
            onInfo = {
                AppRepository.openAppInfo(context, app)
                contextMenuApp = null
            },
            onUninstall = {
                AppRepository.uninstall(context, app)
                contextMenuApp = null
            }
        )
    }
}

@Composable
private fun ClockBlock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }
    val timeFmt = remember { SimpleDateFormat("h:mm", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = timeFmt.format(now),
            color = Color(0xFFF5F2FF),
            fontSize = 64.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = dateFmt.format(now),
            color = Color(0xFFB8AED6),
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(16.dp))
        Surface(shape = RoundedCornerShape(50), color = Color(0x1AFFFFFF)) {
            Text(
                text = "  SzutyiUI  ",
                modifier = Modifier.padding(vertical = 7.dp),
                color = Color(0xFFF5F2FF),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun AppIconImage(app: AppInfo, size: Int = 56) {
    val bitmap = remember(app.packageName) {
        app.icon.toBitmap(width = 144, height = 144).asImageBitmap()
    }
    Image(
        bitmap = bitmap,
        contentDescription = app.label,
        modifier = Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(18.dp))
    )
}

@Composable
private fun Dock(
    apps: List<AppInfo>,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = Color(0x1AFFFFFF)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            apps.forEach { app ->
                Box(
                    modifier = Modifier.pointerInput(app.packageName) {
                        detectTapGestures(
                            onTap = { onTap(app) },
                            onLongPress = { onLongPress(app) }
                        )
                    }
                ) {
                    AppIconImage(app)
                }
            }
        }
    }
}

@Composable
private fun SwipeHandle() {
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .width(120.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0x55FFFFFF))
        )
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    Surface(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(50),
        color = Color(0x1AFFFFFF)
    ) {
        Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                cursorBrush = SolidColor(Color.White),
                decorationBox = { innerField ->
                    if (value.isEmpty()) {
                        Text("Search apps", color = Color(0xFF7A6F99), fontSize = 14.sp)
                    }
                    innerField()
                }
            )
        }
    }
}

@Composable
private fun AppGrid(
    apps: List<AppInfo>,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = modifier.padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(apps, key = { it.packageName }) { app ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(4.dp)
                    .pointerInput(app.packageName) {
                        detectTapGestures(
                            onTap = { onTap(app) },
                            onLongPress = { onLongPress(app) }
                        )
                    }
            ) {
                AppIconImage(app)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = app.label,
                    color = Color(0xFFB8AED6),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun AppContextMenu(
    app: AppInfo,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(app.label) },
        text = { Text("Choose an action for this app.") },
        confirmButton = {
            TextButton(onClick = onInfo) { Text("App info") }
        },
        dismissButton = {
            TextButton(onClick = onUninstall) { Text("Uninstall") }
        }
    )
}
