package com.example.examcalc

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

class CalcException(msg: String) : Exception(msg)

/** Kifejezés-kiértékelő: + - × ÷ ^ ! zárójel, függvények, π, e, Ans, implicit szorzás (2π, 3(4+1)). */
class Evaluator(src: String, private val degrees: Boolean, private val ans: Double) {

    private val s = src.replace(" ", "").replace('×', '*').replace('÷', '/').replace('−', '-')
    private var pos = 0
    private val names = listOf("asin", "acos", "atan", "sin", "cos", "tan", "log", "ln", "Ans", "e")

    fun evaluate(): Double {
        if (s.isEmpty()) throw CalcException("syntax")
        val v = parseExpr()
        if (pos != s.length) throw CalcException("syntax")
        if (v.isNaN() || v.isInfinite()) throw CalcException("math")
        return v
    }

    private fun peek(): Char? = if (pos < s.length) s[pos] else null

    private fun startsPrimary(): Boolean {
        val c = peek() ?: return false
        return c.isDigit() || c == '.' || c == '(' || c == '√' || c.isLetter()
    }

    private fun parseExpr(): Double {
        var v = parseTerm()
        while (true) {
            when (peek()) {
                '+' -> { pos++; v += parseTerm() }
                '-' -> { pos++; v -= parseTerm() }
                else -> return v
            }
        }
    }

    private fun parseTerm(): Double {
        var v = parseUnary()
        while (true) {
            when {
                peek() == '*' -> { pos++; v *= parseUnary() }
                peek() == '/' -> {
                    pos++
                    val d = parseUnary()
                    if (d == 0.0) throw CalcException("div0")
                    v /= d
                }
                startsPrimary() -> v *= parseUnary() // implicit szorzás
                else -> return v
            }
        }
    }

    private fun parseUnary(): Double = when (peek()) {
        '-' -> { pos++; -parseUnary() }
        '+' -> { pos++; parseUnary() }
        else -> parsePower()
    }

    private fun parsePower(): Double {
        val base = parsePostfix()
        if (peek() == '^') {
            pos++
            val r = base.pow(parseUnary()) // jobbra kötő, 2^-3 is jó
            if (r.isNaN()) throw CalcException("math")
            return r
        }
        return base
    }

    private fun parsePostfix(): Double {
        var v = parsePrimary()
        while (peek() == '!') { pos++; v = factorial(v) }
        return v
    }

    private fun parseParen(): Double {
        if (peek() != '(') throw CalcException("syntax")
        pos++
        val v = parseExpr()
        if (peek() == ')') pos++ else if (pos < s.length) throw CalcException("syntax")
        return v // a hiányzó záró zárójelet a sor végén automatikusan pótoljuk
    }

    private fun parsePrimary(): Double {
        val c = peek() ?: throw CalcException("syntax")
        return when {
            c.isDigit() || c == '.' -> parseNumber()
            c == '(' -> parseParen()
            c == 'π' -> { pos++; PI }
            c == '√' -> {
                pos++
                val x = parseParen()
                if (x < 0) throw CalcException("math")
                sqrt(x)
            }
            else -> {
                val name = names.firstOrNull { s.startsWith(it, pos) } ?: throw CalcException("syntax")
                pos += name.length
                when (name) {
                    "e" -> E
                    "Ans" -> ans
                    else -> applyFunc(name, parseParen())
                }
            }
        }
    }

    private fun parseNumber(): Double {
        val start = pos
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        return s.substring(start, pos).toDoubleOrNull() ?: throw CalcException("syntax")
    }

    private fun clean(v: Double) = if (abs(v) < 1e-15) 0.0 else v

    private fun applyFunc(name: String, x: Double): Double {
        val rad = if (degrees) Math.toRadians(x) else x
        fun back(r: Double) = if (degrees) Math.toDegrees(r) else r
        return when (name) {
            "sin" -> clean(sin(rad))
            "cos" -> clean(cos(rad))
            "tan" -> {
                if (abs(cos(rad)) < 1e-15) throw CalcException("math")
                clean(tan(rad))
            }
            "asin" -> { if (abs(x) > 1) throw CalcException("math"); back(asin(x)) }
            "acos" -> { if (abs(x) > 1) throw CalcException("math"); back(acos(x)) }
            "atan" -> back(atan(x))
            "log" -> { if (x <= 0) throw CalcException("math"); log10(x) }
            "ln" -> { if (x <= 0) throw CalcException("math"); ln(x) }
            else -> throw CalcException("syntax")
        }
    }

    private fun factorial(x: Double): Double {
        if (x < 0 || x != floor(x) || x > 170) throw CalcException("math")
        var r = 1.0
        for (i in 2..x.toInt()) r *= i
        return r
    }
}

/** 10 értékes jegyre kerekít; nagyon nagy/kicsi számnál tudományos alak (pl. 6.02E23). */
fun formatResult(v: Double): String {
    if (v == 0.0) return "0"
    val bd = BigDecimal(v).round(MathContext(10)).stripTrailingZeros()
    val a = abs(v)
    if (a < 1e10 && a >= 1e-4) return bd.toPlainString()
    val digits = bd.unscaledValue().abs().toString()
    val exp = digits.length - 1 - bd.scale()
    val mant = if (digits.length > 1) digits[0] + "." + digits.substring(1) else digits
    return (if (v < 0) "-" else "") + mant + "E" + exp
}

/** Tudományos számológép felület – a rendelkezésre álló helyet kitölti. */
class CalculatorView(context: Context) : LinearLayout(context) {

    private enum class Kind { VALUE, OP }

    private var degrees = true
    private var expr = ""
    private var ans = 0.0
    private var justEvaluated = false

    private val exprView = TextView(context).apply {
        textSize = 20f
        gravity = Gravity.END
        maxLines = 2
        setTextColor(Color.DKGRAY)
        setPadding(12, 4, 12, 0)
    }
    private val resultView = TextView(context).apply {
        textSize = 30f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.END
        setTextColor(Color.BLACK)
        setPadding(12, 0, 12, 8)
    }
    private var modeBtn: Button? = null

    private val NUM = "#ECEFF1"
    private val FN = "#CFD8DC"
    private val OPC = "#1565C0"
    private val RED = "#C62828"
    private val GREEN = "#2E7D32"
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    init {
        orientation = VERTICAL
        addView(exprView, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(resultView, LinearLayout.LayoutParams(MATCH, WRAP))

        val mode = key("DEG", FN) { toggleMode() }
        modeBtn = mode

        addRow(mode to 1f, v("sin", "sin(") to 1f, v("cos", "cos(") to 1f, v("tan", "tan(") to 1f,
            key("⌫", FN) { backspace() } to 1f)
        addRow(v("π") to 1f, v("sin⁻¹", "asin(") to 1f, v("cos⁻¹", "acos(") to 1f, v("tan⁻¹", "atan(") to 1f,
            key("AC", RED, "#FFFFFF") { clearAll() } to 1f)
        addRow(o("x²", "^2") to 1f, o("xʸ", "^") to 1f, v("√", "√(") to 1f, v("log", "log(") to 1f, v("ln", "ln(") to 1f)
        addRow(v("(") to 1f, o(")") to 1f, o("x!", "!") to 1f, v("e") to 1f, o("×10ˣ", "×10^") to 1f)
        addRow(n("7") to 1f, n("8") to 1f, n("9") to 1f, o("÷", "÷", OPC, "#FFFFFF") to 1f, o("×", "×", OPC, "#FFFFFF") to 1f)
        addRow(n("4") to 1f, n("5") to 1f, n("6") to 1f, o("−", "−", OPC, "#FFFFFF") to 1f, o("+", "+", OPC, "#FFFFFF") to 1f)
        addRow(n("1") to 1f, n("2") to 1f, n("3") to 1f, v("Ans") to 1f, o("x⁻¹", "^(−1)") to 1f)
        addRow(n("0") to 1f, n(".") to 1f, key("=", GREEN, "#FFFFFF") { evaluate() } to 3f)
    }

    // ---- gombok ----
    private fun key(label: String, bg: String, fg: String = "#212121", onClick: () -> Unit): Button =
        Button(context).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.parseColor(fg))
            minWidth = 0
            minHeight = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bg))
                cornerRadius = 20f
            }
            setOnClickListener { onClick() }
        }

    private fun n(label: String) = key(label, NUM) { insert(label, Kind.VALUE) }
    private fun v(label: String, text: String = label) = key(label, FN) { insert(text, Kind.VALUE) }
    private fun o(label: String, text: String = label, bg: String = FN, fg: String = "#212121") =
        key(label, bg, fg) { insert(text, Kind.OP) }

    private fun addRow(vararg items: Pair<Button, Float>) {
        val r = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        for ((b, w) in items) {
            r.addView(b, LinearLayout.LayoutParams(0, MATCH, w).apply { setMargins(3, 3, 3, 3) })
        }
        addView(r, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    // ---- logika ----
    private fun insert(text: String, kind: Kind) {
        if (justEvaluated) {
            expr = if (kind == Kind.OP) "Ans" else ""
            justEvaluated = false
        }
        resultView.text = ""
        expr += text
        exprView.text = expr
    }

    private val tokens = listOf("asin(", "acos(", "atan(", "sin(", "cos(", "tan(", "log(", "ln(", "√(", "Ans")

    private fun backspace() {
        justEvaluated = false
        val t = tokens.firstOrNull { expr.endsWith(it) }
        expr = if (t != null) expr.dropLast(t.length) else expr.dropLast(1)
        exprView.text = expr
    }

    private fun clearAll() {
        expr = ""
        justEvaluated = false
        exprView.text = ""
        resultView.text = ""
    }

    private fun toggleMode() {
        degrees = !degrees
        modeBtn?.text = if (degrees) "DEG" else "RAD"
    }

    private fun evaluate() {
        if (expr.isEmpty()) return
        try {
            val r = Evaluator(expr, degrees, ans).evaluate()
            ans = r
            resultView.text = formatResult(r)
            justEvaluated = true
        } catch (e: CalcException) {
            resultView.text = when (e.message) {
                "div0" -> "Nullával osztás"
                "math" -> "Matematikai hiba"
                else -> "Szintaktikai hiba"
            }
        }
    }
}
