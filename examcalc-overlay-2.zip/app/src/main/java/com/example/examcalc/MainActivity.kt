package com.example.examcalc

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/*
 * AndroidManifest.xml:
 *   <activity android:name=".MainActivity" android:exported="true"
 *             android:screenOrientation="portrait">
 *     <intent-filter>
 *       <action android:name="android.intent.action.MAIN"/>
 *       <category android:name="android.intent.category.LAUNCHER"/>
 *     </intent-filter>
 *   </activity>
 * (Overlay permission is NOT needed with this approach.)
 */
class MainActivity : AppCompatActivity() {

    private val EXAM_MINUTES = 45L

    private lateinit var nm: NotificationManager
    private lateinit var status: TextView
    private lateinit var pinInput: EditText
    private lateinit var actionBtn: Button

    private var pin: String? = null          // lives only in memory, set by the teacher at start
    private var examRunning = false
    private var timer: CountDownTimer? = null
    private var savedFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var leftAt = 0L
    private val exitLog = mutableListOf<String>()

    private val backBlocker = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { /* block back while the exam runs */ }
    }

    private val dndWatcher = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (examRunning &&
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_NONE) {
                exitLog += "${now()} DND turned off by the student, turned back on"
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nm = getSystemService(NotificationManager::class.java)
        onBackPressedDispatcher.addCallback(this, backBlocker)

        status = TextView(this).apply { textSize = 18f; text = "Teacher: set a PIN and start" }
        pinInput = EditText(this).apply { hint = "Teacher PIN" }
        actionBtn = Button(this).apply { text = "Start exam"; setOnClickListener { onActionClick() } }

        val calculator = CalculatorView(this)

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(status); addView(pinInput); addView(actionBtn)
            addView(calculator, LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
    }

    private fun onActionClick() {
        val entered = pinInput.text.toString()
        if (!examRunning) startExam(entered) else if (entered == pin) endExam("teacher PIN")
        else Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show()
        pinInput.text.clear()
    }

    private fun startExam(newPin: String) {
        if (newPin.length < 4) { toast("PIN must be at least 4 digits"); return }
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Allow Do Not Disturb access, then come back")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Engedélyezd a „Megjelenés legfelül” opciót, majd gyere vissza")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Engedélyezd az akkumulátor-optimalizálás megkerülését, majd gyere vissza")
            @Suppress("BatteryLife")
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        pin = newPin
        examRunning = true
        exitLog.clear()

        savedFilter = nm.currentInterruptionFilter
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        ContextCompat.registerReceiver(
            this, dndWatcher,
            IntentFilter(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        backBlocker.isEnabled = true
        ExamState.endAtMs = System.currentTimeMillis() + EXAM_MINUTES * 60_000
        ExamState.running = true
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        startLockTask() // without Device Owner the system asks the student to confirm pinning

        actionBtn.text = "End exam (PIN)"
        pinInput.hint = "Teacher PIN to end"

        timer = object : CountDownTimer(EXAM_MINUTES * 60_000, 1_000) {
            override fun onTick(ms: Long) {
                status.text = "Time left: %d:%02d".format(ms / 60_000, (ms / 1_000) % 60)
            }
            override fun onFinish() = endExam("timer")
        }.start()
    }

    private fun endExam(reason: String) {
        examRunning = false
        ExamState.running = false
        stopService(Intent(this, OverlayService::class.java))
        timer?.cancel()
        try { unregisterReceiver(dndWatcher) } catch (_: Exception) {}
        nm.setInterruptionFilter(savedFilter)
        backBlocker.isEnabled = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { stopLockTask() } catch (_: Exception) {}

        pin = null
        actionBtn.text = "Start exam"
        pinInput.hint = "Teacher PIN"
        status.text = "Finished ($reason).\n" +
            (if (exitLog.isEmpty()) "No exits recorded." else exitLog.joinToString("\n"))
    }

    // Exit log: every time the app goes to the background during the exam
    override fun onPause() {
        super.onPause()
        ExamState.inForeground = false
        if (examRunning) leftAt = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        ExamState.inForeground = true
        if (examRunning && leftAt != 0L) {
            val secs = (System.currentTimeMillis() - leftAt) / 1000
            exitLog += "${now()} left the app for ${secs}s"
            leftAt = 0L
        }
    }

    private fun now() = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        .format(java.util.Date())

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
