package com.example.examcalc

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/*
 * AndroidManifest.xml:
 *   <activity android:name=".MainActivity" android:exported="true"
 *             android:screenOrientation="portrait">
 *     <intent-filter>
 *       <action android:name="android.intent.action.MAIN"/>
 *       <category android:name="android.intent.category.LAUNCHER"/>
 *     </intent-filter>
 *   </activity>
 * (Overlay permission is NOT needed with this approach.)
 */
class MainActivity : AppCompatActivity() {

    private val EXAM_MINUTES = 45L
    private val TEST_SECONDS = 60L
    private var testMode = false   // teszt: 1 perc, PIN nélkül is kiléphető
    private lateinit var testBtn: Button
    private lateinit var calc: CalculatorView
    private lateinit var menuBtn: Button
    private lateinit var themeBtn: Button
    private var themeIdx = 0

    private lateinit var nm: NotificationManager
    private lateinit var status: TextView
    private lateinit var pinInput: EditText
    private lateinit var actionBtn: Button
    private lateinit var menuDialog: AlertDialog
    private lateinit var timeView: TextView
    private lateinit var root: LinearLayout
    private var barPadPx = 0   // hely a felső időkijelző sávnak, amíg fut a dolgozat

    private var pin: String? = null          // lives only in memory, set by the teacher at start
    private var examRunning = false
    private var timer: CountDownTimer? = null
    private var savedFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var leftAt = 0L
    private val exitLog = mutableListOf<String>()

    private val backBlocker = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { /* block back while the exam runs */ }
    }

    private val dndWatcher = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (examRunning &&
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_NONE) {
                exitLog += "${now()} a diák kikapcsolta a DND-t, visszakapcsolva"
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nm = getSystemService(NotificationManager::class.java)
        onBackPressedDispatcher.addCallback(this, backBlocker)

        // Teljes képernyő (a rendszersávok elrejtése az onWindowFocusChanged-ben)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val dp = resources.displayMetrics.density
        fun px(n: Int) = (n * dp).toInt()

        // ---- tanári menü (párbeszédablak) ----
        status = TextView(this).apply { textSize = 18f; text = "Tanár: adj meg egy PIN-t, majd indítsd" }
        pinInput = EditText(this).apply {
            hint = "Tanári PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        actionBtn = Button(this).apply { text = "Dolgozat indítása"; setOnClickListener { onActionClick() } }
        testBtn = Button(this).apply {
            text = "Teszt (1 perc, PIN nélkül kiléphető)"
            setOnClickListener {
                if (!examRunning) { startExam(pinInput.text.toString(), test = true); pinInput.text.clear() }
            }
        }
        val menuLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(8))
            addView(status); addView(pinInput); addView(actionBtn); addView(testBtn)
        }
        menuDialog = AlertDialog.Builder(this)
            .setTitle("Tanári menü")
            .setView(menuLayout)
            .setNegativeButton("Bezár", null)
            .create()

        // ---- felső sor: menügomb bal oldalon, idő jobbra ----
        menuBtn = Button(this).apply {
            text = "☰"
            textSize = 18f
            minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { menuDialog.show() }
        }
        themeBtn = Button(this).apply {
            text = "🎨"
            textSize = 16f
            minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { applyTheme((themeIdx + 1) % CalcThemes.all.size) }
        }
        timeView = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setTextColor(Color.DKGRAY)
        }
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(menuBtn, LinearLayout.LayoutParams(px(44), px(44)))
            addView(themeBtn, LinearLayout.LayoutParams(px(44), px(44)).apply { leftMargin = px(8) })
            addView(timeView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }

        // ---- gyökér: felül a sor, alatta a számológép kitölti a képernyőt ----
        calc = CalculatorView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(topRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(calc, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left + px(6), i.top + barPadPx, i.right + px(6), i.bottom + px(6))
            insets
        }
        setContentView(root)
        applyTheme(getSharedPreferences("prefs", MODE_PRIVATE).getInt("theme", 0))
    }

    private fun applyTheme(idx: Int) {
        themeIdx = idx.coerceIn(0, CalcThemes.all.size - 1)
        val t = CalcThemes.all[themeIdx]
        calc.applyTheme(t)
        root.setBackgroundColor(t.bg)
        timeView.setTextColor(t.exprText)
        for (b in listOf(menuBtn, themeBtn)) {
            b.setTextColor(t.fn.second)
            b.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(t.fn.first); cornerRadius = 20f
            }
        }
        getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("theme", themeIdx).apply()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            WindowInsetsControllerCompat(window, window.decorView).apply {
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    private fun setBarPad(on: Boolean) {
        barPadPx = if (on) (40 * resources.displayMetrics.density).toInt() else 0
        ViewCompat.requestApplyInsets(root)
    }

    private fun onActionClick() {
        val entered = pinInput.text.toString()
        if (!examRunning) startExam(entered, test = false)
        else if (testMode || entered == pin) endExam(if (testMode) "teszt" else "tanári PIN")
        else Toast.makeText(this, "Hibás PIN", Toast.LENGTH_SHORT).show()
        pinInput.text.clear()
    }

    private fun startExam(newPin: String, test: Boolean) {
        if (!test && newPin.length < 4) { toast("A PIN legalább 4 számjegy legyen"); return }
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Engedélyezd a Ne zavarjanak hozzáférést, majd gyere vissza")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Engedélyezd a „Megjelenés legfelül” opciót, majd gyere vissza")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Engedélyezd az akkumulátor-optimalizálás megkerülését, majd gyere vissza")
            @Suppress("BatteryLife")
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        pin = newPin
        testMode = test
        examRunning = true
        exitLog.clear()

        savedFilter = nm.currentInterruptionFilter
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        ContextCompat.registerReceiver(
            this, dndWatcher,
            IntentFilter(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        backBlocker.isEnabled = true
        val totalMs = if (test) TEST_SECONDS * 1_000 else EXAM_MINUTES * 60_000
        ExamState.endAtMs = System.currentTimeMillis() + totalMs
        ExamState.running = true
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        startLockTask() // without Device Owner the system asks the student to confirm pinning

        setBarPad(true)
        menuDialog.dismiss()
        actionBtn.text = if (test) "Teszt vége" else "Dolgozat vége (PIN)"
        pinInput.hint = "Tanári PIN a befejezéshez"

        timer = object : CountDownTimer(totalMs, 1_000) {
            override fun onTick(ms: Long) {
                val t = "%d:%02d".format(ms / 60_000, (ms / 1_000) % 60)
                status.text = "Hátralévő idő: $t"
                timeView.text = "⏱ $t"
            }
            override fun onFinish() = endExam("timer")
        }.start()
    }

    private fun endExam(reason: String) {
        examRunning = false
        ExamState.running = false
        stopService(Intent(this, OverlayService::class.java))
        timer?.cancel()
        try { unregisterReceiver(dndWatcher) } catch (_: Exception) {}
        nm.setInterruptionFilter(savedFilter)
        backBlocker.isEnabled = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { stopLockTask() } catch (_: Exception) {}

        pin = null
        testMode = false
        setBarPad(false)
        timeView.text = ""
        actionBtn.text = "Dolgozat indítása"
        pinInput.hint = "Tanári PIN"
        status.text = "Befejezve ($reason).\n" +
            (if (exitLog.isEmpty()) "Nem volt kilépés." else exitLog.joinToString("\n"))
        menuDialog.show() // a tanár rögtön látja az eredményt és a kilépési naplót
    }

    // Exit log: every time the app goes to the background during the exam
    override fun onPause() {
        super.onPause()
        ExamState.inForeground = false
        if (examRunning) leftAt = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        ExamState.inForeground = true
        if (examRunning && leftAt != 0L) {
            val secs = (System.currentTimeMillis() - leftAt) / 1000
            exitLog += "${now()} elhagyta az appot ${secs} mp-re"
            leftAt = 0L
        }
    }

    private fun now() = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        .format(java.util.Date())

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
