package com.example.examcalc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Közös állapot az Activity és a Service között. */
object ExamState {
    @Volatile var running = false
    @Volatile var endAtMs = 0L
    @Volatile var inForeground = false
}

/**
 * Vizsga alatt:
 *  - mindig legfelül tart egy vékony sávot (hátralévő idő) minden app fölött
 *  - ha a diák elhagyja a számológépet, a sávra koppintva (vagy automatikusan) visszahozza
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bar: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            if (!ExamState.running) { stopSelf(); return }
            val left = (ExamState.endAtMs - System.currentTimeMillis()).coerceAtLeast(0)
            val away = !ExamState.inForeground
            bar?.text = (if (away) "⚠ Vissza a számológépbe! " else "") +
                "Hátralévő idő: %d:%02d".format(left / 60_000, (left / 1_000) % 60)
            bar?.setBackgroundColor(if (away) Color.parseColor("#D32F2F") else Color.parseColor("#CC1B5E20"))
            if (away) bringToFront()
            handler.postDelayed(this, 1_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(1, buildNotification())
        addBar()
        handler.post(tick)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("exam", "Dolgozat", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "exam")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Dolgozat fut")
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .setOngoing(true)
            .build()
    }

    private fun addBar() {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(16, 12, 16, 12)
            setOnClickListener { bringToFront() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }
        wm.addView(tv, lp)
        bar = tv
    }

    // A SYSTEM_ALERT_WINDOW engedély kivételt ad a háttérből indítás tiltása alól.
    private fun bringToFront() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        bar?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bar = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
