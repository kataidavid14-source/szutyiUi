package com.example.examcalc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Közös állapot az Activity, a Service és a BootReceiver között. */
object ExamState {
    @Volatile var running = false
    @Volatile var endAtMs = 0L
    @Volatile var inForeground = false
    @Volatile var testMode = false
    /** Eddig (ms időbélyeg) nem riaszt: a rendszer rögzítés-megerősítő ablaka miatt. */
    @Volatile var armedAtMs = 0L
    /** Újraindítás után a szolgáltatás indulásakor egyből riasszon. */
    @Volatile var pendingAlarm = false
    /** Az Activity ezt hívja, ha a diák elhagyta az appot. */
    @Volatile var onExit: (() -> Unit)? = null
}

/** Zseblámpa (folyamatos fény, nem villog) + hangos ébresztőhang meghatározott ideig. */
class ExitAlarm(private val ctx: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private val am = ctx.getSystemService(AudioManager::class.java)
    private val cm = ctx.getSystemService(CameraManager::class.java)
    private var player: MediaPlayer? = null
    private var tone: ToneGenerator? = null
    private var oldVol = -1
    private var torchId: String? = null
    private val stopRunnable = Runnable { stop() }

    var active = false
        private set

    fun start(durationMs: Long) {
        if (active) return
        active = true

        // ébresztő-hangerő maximumra (a DND "csak ébresztők" módban az ébresztő átszól)
        try {
            oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (_: Exception) {}

        try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(ctx, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) {
            try {
                tone = ToneGenerator(AudioManager.STREAM_ALARM, 100).also {
                    it.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, durationMs.toInt())
                }
            } catch (_: Exception) {}
        }

        try {
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id != null) { cm.setTorchMode(id, true); torchId = id }
        } catch (_: Exception) {}

        handler.postDelayed(stopRunnable, durationMs)
    }

    fun stop() {
        handler.removeCallbacks(stopRunnable)
        if (!active) return
        active = false
        try { player?.stop(); player?.release() } catch (_: Exception) {}
        player = null
        try { tone?.release() } catch (_: Exception) {}
        tone = null
        torchId?.let { try { cm.setTorchMode(it, false) } catch (_: Exception) {} }
        torchId = null
        if (oldVol >= 0) { try { am.setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0) } catch (_: Exception) {} }
        oldVol = -1
    }
}

/**
 * Vizsga alatt:
 *  - mindig legfelül tart egy vékony sávot (hátralévő idő) minden app fölött
 *  - ha a diák elhagyja a számológépet: riaszt (lámpa + hang) és visszahozza az appot
 *  - újraindítás után is folytatja (állapot: ExamStore)
 */
class OverlayService : Service() {

    private val ALARM_MS = 10_000L

    private lateinit var wm: WindowManager
    private lateinit var alarm: ExitAlarm
    private var bar: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var ticks = 0

    private val tick = object : Runnable {
        override fun run() {
            if (!ExamState.running) { stopSelf(); return }
            val left = (ExamState.endAtMs - System.currentTimeMillis()).coerceAtLeast(0)
            val away = !ExamState.inForeground
            bar?.text = (if (away) "⚠ Vissza a számológépbe! " else "") +
                "Hátralévő idő: %d:%02d".format(left / 60_000, (left / 1_000) % 60)
            bar?.setBackgroundColor(if (away) Color.parseColor("#D32F2F") else Color.parseColor("#CC1B5E20"))
            if (away) bringToFront()
            if (ticks++ % 5 == 0) ExamStore.touch(this@OverlayService) // életjel
            handler.postDelayed(this, 1_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())

        // Ha a folyamat újraindult, az állapotot a tárolóból töltjük vissza
        if (!ExamState.running && !ExamStore.restore(this)) { stopSelf(); return }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        alarm = ExitAlarm(this)
        addBar()

        ExamState.onExit = { triggerAlarm() }
        if (ExamState.pendingAlarm) { ExamState.pendingAlarm = false; triggerAlarm() }
        handler.post(tick)
    }

    private fun triggerAlarm() {
        if (alarm.active) return
        ExamStore.appendLog(this, "${ExamStore.stamp()} riasztás (lámpa + hang)")
        alarm.start(ALARM_MS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("exam", "Dolgozat", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "exam")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Dolgozat fut")
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .setOngoing(true)
            .build()
    }

    private fun addBar() {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(16, 12, 16, 12)
            setOnClickListener { bringToFront() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }
        wm.addView(tv, lp)
        bar = tv
    }

    // A SYSTEM_ALERT_WINDOW engedély kivételt ad a háttérből indítás tiltása alól.
    private fun bringToFront() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ExamState.onExit = null
        if (::alarm.isInitialized) alarm.stop()
        bar?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bar = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
