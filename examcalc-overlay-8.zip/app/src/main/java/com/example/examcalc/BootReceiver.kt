package com.example.examcalc

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Telefon-újraindítás után a futó dolgozatot visszahozza (a szolgáltatás előtérbe hozza az appot). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!ExamStore.isRunning(ctx)) return

        if (ExamStore.endAt(ctx) <= System.currentTimeMillis()) {
            // közben lejárt: állítsuk vissza a DND-t és zárjuk le
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(ExamStore.savedFilter(ctx))
            ExamStore.clear(ctx)
            return
        }
        ExamState.pendingAlarm = true
        ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
    }
}
