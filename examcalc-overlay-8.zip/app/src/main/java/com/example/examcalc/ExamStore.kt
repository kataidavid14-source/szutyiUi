package com.example.examcalc

import android.app.NotificationManager
import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A dolgozat állapota tartósan (SharedPreferences), hogy az app újraindítása vagy
 * a telefon újraindítása után is folytatódjon. A PIN csak sózott hash-ként tárolódik.
 */
object ExamStore {

    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("exam", Context.MODE_PRIVATE)

    fun stamp(): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

    private fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun begin(ctx: Context, endAt: Long, pin: String, test: Boolean, savedFilter: Int) {
        val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val salt = saltBytes.joinToString("") { "%02x".format(it) }
        p(ctx).edit().clear()
            .putBoolean("running", true)
            .putLong("endAt", endAt)
            .putBoolean("test", test)
            .putInt("filter", savedFilter)
            .putString("salt", salt)
            .putString("hash", hash(salt, pin))
            .putLong("seen", System.currentTimeMillis())
            .putString("log", "")
            .apply()
    }

    fun isRunning(ctx: Context) = p(ctx).getBoolean("running", false)
    fun endAt(ctx: Context) = p(ctx).getLong("endAt", 0L)
    fun isTest(ctx: Context) = p(ctx).getBoolean("test", false)
    fun savedFilter(ctx: Context) =
        p(ctx).getInt("filter", NotificationManager.INTERRUPTION_FILTER_ALL)
    fun lastSeen(ctx: Context) = p(ctx).getLong("seen", System.currentTimeMillis())

    /** "Életjel": ebből tudjuk meg, mennyi ideig nem futott az app. */
    fun touch(ctx: Context) {
        p(ctx).edit().putLong("seen", System.currentTimeMillis()).apply()
    }

    fun checkPin(ctx: Context, entered: String): Boolean {
        val salt = p(ctx).getString("salt", null) ?: return false
        return hash(salt, entered) == p(ctx).getString("hash", null)
    }

    fun appendLog(ctx: Context, line: String) {
        val cur = p(ctx).getString("log", "") ?: ""
        p(ctx).edit().putString("log", if (cur.isEmpty()) line else cur + "\n" + line).apply()
    }

    fun log(ctx: Context): List<String> =
        (p(ctx).getString("log", "") ?: "").split("\n").filter { it.isNotEmpty() }

    fun clear(ctx: Context) {
        p(ctx).edit().clear().apply()
    }

    /** Betölti az állapotot az ExamState-be, ha van még érvényes (le nem járt) dolgozat. */
    fun restore(ctx: Context): Boolean {
        if (!isRunning(ctx) || endAt(ctx) <= System.currentTimeMillis()) return false
        ExamState.running = true
        ExamState.endAtMs = endAt(ctx)
        ExamState.testMode = isTest(ctx)
        return true
    }
}
