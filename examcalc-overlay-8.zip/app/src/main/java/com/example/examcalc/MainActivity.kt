package com.example.examcalc

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private val EXAM_MINUTES = 45L
    private val TEST_SECONDS = 60L
    private var testMode = false   // teszt: 1 perc, PIN nélkül is kiléphető
    private lateinit var testBtn: Button
    private lateinit var nameInput: EditText
    private lateinit var hostInput: EditText
    private lateinit var codeInput: EditText
    private lateinit var saveProfileBtn: Button
    private lateinit var linkStatus: TextView
    private lateinit var calc: CalculatorView
    private lateinit var menuBtn: Button
    private lateinit var themeBtn: Button
    private var themeIdx = 0

    private lateinit var nm: NotificationManager
    private lateinit var status: TextView
    private lateinit var pinInput: EditText
    private lateinit var actionBtn: Button
    private lateinit var menuDialog: AlertDialog
    private lateinit var timeView: TextView
    private lateinit var root: LinearLayout
    private var barPadPx = 0   // hely a felső időkijelző sávnak, amíg fut a dolgozat

    private var examRunning = false
    private var timer: CountDownTimer? = null
    private var savedFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var leftAt = 0L
    private var leftScreenOff = false
    private val ARM_DELAY_MS = 20_000L
    private val uiHandler = Handler(Looper.getMainLooper())
    private var lastExitMs = 0L      // kettős riasztás/napló elkerülése
    private var lastRelockMs = 0L   // ennyi ideig nem riaszt indítás után (rendszer-megerősítő ablak)

    private val backBlocker = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { /* block back while the exam runs */ }
    }

    private val dndWatcher = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (examRunning &&
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALARMS) {
                ExamStore.appendLog(this@MainActivity, "${ExamStore.stamp()} a diák módosította a DND-t, visszaállítva")
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nm = getSystemService(NotificationManager::class.java)
        onBackPressedDispatcher.addCallback(this, backBlocker)

        // Teljes képernyő (a rendszersávok elrejtése az onWindowFocusChanged-ben)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        val dp = resources.displayMetrics.density
        fun px(n: Int) = (n * dp).toInt()

        // ---- tanári menü (párbeszédablak) ----
        status = TextView(this).apply { textSize = 18f; text = "Tanár: adj meg egy PIN-t, majd indítsd" }
        pinInput = EditText(this).apply {
            hint = "Tanári PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        actionBtn = Button(this).apply { text = "Dolgozat indítása"; setOnClickListener { onActionClick() } }
        testBtn = Button(this).apply {
            text = "Teszt (1 perc, PIN nélkül kiléphető)"
            setOnClickListener {
                if (!examRunning) { startExam(pinInput.text.toString(), test = true); pinInput.text.clear() }
            }
        }
        // ---- profil + kapcsolat a tanári apphoz ----
        nameInput = EditText(this).apply { hint = "Név (pl. Kiss Anna)"; setText(TeacherLink.name(this@MainActivity)) }
        hostInput = EditText(this).apply { hint = "Tanári gép IP (pl. 192.168.43.1)"; setText(TeacherLink.host(this@MainActivity)) }
        codeInput = EditText(this).apply {
            hint = "Kapcsolati kód"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(TeacherLink.code(this@MainActivity))
        }
        linkStatus = TextView(this).apply { textSize = 14f }
        saveProfileBtn = Button(this).apply {
            text = "Mentés és csatlakozás"
            setOnClickListener {
                TeacherLink.save(this@MainActivity, nameInput.text.toString(), hostInput.text.toString(), codeInput.text.toString())
                TeacherLink.start(applicationContext)
                TeacherLink.reconnect()
                toast("Mentve")
            }
        }
        val menuLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(8))
            addView(status); addView(pinInput); addView(actionBtn); addView(testBtn)
            addView(TextView(this@MainActivity).apply { text = "\nProfil és kapcsolat"; textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
            addView(nameInput); addView(hostInput); addView(codeInput); addView(saveProfileBtn); addView(linkStatus)
        }
        menuDialog = AlertDialog.Builder(this)
            .setTitle("Tanári menü")
            .setView(ScrollView(this).apply { addView(menuLayout) })
            .setNegativeButton("Bezár", null)
            .create()
        // a kapcsolat állapotát másodpercenként frissíti, amíg a menü nyitva van
        val linkRefresh = object : Runnable {
            override fun run() {
                linkStatus.text = "Kapcsolat: " + TeacherLink.statusText(this@MainActivity)
                uiHandler.postDelayed(this, 1_000)
            }
        }
        menuDialog.setOnShowListener { uiHandler.post(linkRefresh) }
        menuDialog.setOnDismissListener { uiHandler.removeCallbacks(linkRefresh) }

        // ---- felső sor: menügomb bal oldalon, idő jobbra ----
        menuBtn = Button(this).apply {
            text = "☰"
            textSize = 18f
            minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { menuDialog.show() }
        }
        themeBtn = Button(this).apply {
            text = "🎨"
            textSize = 16f
            minWidth = 0; minHeight = 0; minimumWidth = 0; minimumHeight = 0
            setPadding(0, 0, 0, 0)
            setOnClickListener { applyTheme((themeIdx + 1) % CalcThemes.all.size) }
        }
        timeView = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setTextColor(Color.DKGRAY)
        }
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(menuBtn, LinearLayout.LayoutParams(px(44), px(44)))
            addView(themeBtn, LinearLayout.LayoutParams(px(44), px(44)).apply { leftMargin = px(8) })
            addView(timeView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }

        // ---- gyökér: felül a sor, alatta a számológép kitölti a képernyőt ----
        calc = CalculatorView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(topRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(calc, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left + px(6), i.top + barPadPx, i.right + px(6), i.bottom + px(6))
            insets
        }
        setContentView(root)
        applyTheme(getSharedPreferences("prefs", MODE_PRIVATE).getInt("theme", 0))
        TeacherLink.start(applicationContext)
        resumeIfRunning()
    }

    private fun applyTheme(idx: Int) {
        themeIdx = idx.coerceIn(0, CalcThemes.all.size - 1)
        val t = CalcThemes.all[themeIdx]
        calc.applyTheme(t)
        root.setBackgroundColor(t.bg)
        timeView.setTextColor(t.exprText)
        for (b in listOf(menuBtn, themeBtn)) {
            b.setTextColor(t.fn.second)
            b.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(t.fn.first); cornerRadius = 20f
            }
        }
        getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("theme", themeIdx).apply()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            uiHandler.removeCallbacks(focusCheck)
            if (examRunning) ExamState.inForeground = true
            WindowInsetsControllerCompat(window, window.decorView).apply {
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.systemBars())
            }
        } else if (examRunning) {
            // Osztott képernyőnél az app "él" marad (nincs onPause), de elveszti a fókuszt.
            uiHandler.postDelayed(focusCheck, 1_500)
        }
    }

    private val focusCheck = Runnable {
        val interactive = getSystemService(PowerManager::class.java).isInteractive
        if (examRunning && interactive && !hasWindowFocus() && !menuDialog.isShowing) {
            val why = if (isInMultiWindowMode) "osztott képernyőt nyitott" else "elvesztette a fókuszt (értesítési sáv / másik ablak)"
            reportExit(why)
            ExamState.inForeground = false   // a szolgáltatás piros sávot mutat és visszahozza az appot
        }
    }

    /** Kilépés, amit nem az onPause jelez (osztott képernyő, fókuszvesztés). */
    private fun reportExit(why: String) {
        val now = System.currentTimeMillis()
        if (now < ExamState.armedAtMs || now - lastExitMs < 3_000) return
        lastExitMs = now
        ExamStore.appendLog(this, "${ExamStore.stamp()} $why")
        ExamState.onExit?.invoke()
    }

    /** Ha a diák feloldotta a képernyő-rögzítést, újra kéri (a rendszer megerősítést kér). */
    private fun relockIfNeeded() {
        if (!examRunning) return
        val now = System.currentTimeMillis()
        if (now < ExamState.armedAtMs || now - lastRelockMs < 10_000) return
        val am = getSystemService(ActivityManager::class.java)
        if (am.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) {
            lastRelockMs = now
            try { startLockTask() } catch (_: Exception) {}
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        relockIfNeeded() // a szolgáltatás visszahozáskor ide érkezik
    }

    private fun setBarPad(on: Boolean) {
        barPadPx = if (on) (40 * resources.displayMetrics.density).toInt() else 0
        ViewCompat.requestApplyInsets(root)
    }

    /** Dolgozat alatt a profil (név, cím, kód) nem szerkeszthető. */
    private fun setProfileEditable(on: Boolean) {
        for (v in listOf<android.view.View>(nameInput, hostInput, codeInput, saveProfileBtn)) v.isEnabled = on
    }

    private fun onActionClick() {
        val entered = pinInput.text.toString()
        if (!examRunning) startExam(entered, test = false)
        else if (testMode || ExamStore.checkPin(this, entered)) endExam(if (testMode) "teszt" else "tanári PIN")
        else Toast.makeText(this, "Hibás PIN", Toast.LENGTH_SHORT).show()
        pinInput.text.clear()
    }

    private fun startExam(newPin: String, test: Boolean) {
        if (!test && newPin.length < 4) { toast("A PIN legalább 4 számjegy legyen"); return }
        if (!nm.isNotificationPolicyAccessGranted) {
            toast("Engedélyezd a Ne zavarjanak hozzáférést, majd gyere vissza")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Engedélyezd a „Megjelenés legfelül” opciót, majd gyere vissza")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Engedélyezd az akkumulátor-optimalizálás megkerülését, majd gyere vissza")
            @Suppress("BatteryLife")
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        // Hálózat: WiFi be, mobilnet ki (ezt Android 10 óta nem kapcsolhatja az app, csak ellenőrizheti)
        if (!test) {
            when (NetCheck.problem(this)) {
                NetCheck.CELL -> {
                    toast("Kapcsold ki a mobilnetet (csak WiFi), majd indítsd újra")
                    startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                    return
                }
                NetCheck.NO_WIFI -> {
                    toast("Csatlakozz a WiFi-hez, majd indítsd újra")
                    startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    return
                }
            }
        }
        val totalMs = if (test) TEST_SECONDS * 1_000 else EXAM_MINUTES * 60_000
        savedFilter = nm.currentInterruptionFilter
        ExamStore.begin(this, System.currentTimeMillis() + totalMs, newPin, test, savedFilter)
        ExamState.armedAtMs = System.currentTimeMillis() + ARM_DELAY_MS
        activateExam(totalMs, test)
    }

    /** Közös indítás: új dolgozatnál és újraindítás utáni folytatásnál is. */
    private fun activateExam(remainingMs: Long, test: Boolean) {
        testMode = test
        examRunning = true

        // "Csak ébresztők" mód: a hívások/értesítések némák, de a riasztó hang átszól
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
        }
        ContextCompat.registerReceiver(
            this, dndWatcher,
            IntentFilter(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        backBlocker.isEnabled = true
        ExamState.endAtMs = System.currentTimeMillis() + remainingMs
        ExamState.testMode = test
        ExamState.running = true
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        startLockTask() // without Device Owner the system asks the student to confirm pinning

        setBarPad(true)
        menuDialog.dismiss()
        setProfileEditable(false)
        actionBtn.text = if (test) "Teszt vége" else "Dolgozat vége (PIN)"
        pinInput.hint = "Tanári PIN a befejezéshez"

        timer?.cancel()
        timer = object : CountDownTimer(remainingMs, 1_000) {
            override fun onTick(ms: Long) {
                val t = "%d:%02d".format(ms / 60_000, (ms / 1_000) % 60)
                status.text = "Hátralévő idő: $t"
                timeView.text = "⏱ $t"
            }
            override fun onFinish() = endExam("lejárt az idő")
        }.start()
    }

    /** Ha az app/telefon újraindult dolgozat közben, itt folytatódik. */
    private fun resumeIfRunning() {
        if (!ExamStore.isRunning(this)) return
        val remaining = ExamStore.endAt(this) - System.currentTimeMillis()
        savedFilter = ExamStore.savedFilter(this)
        testMode = ExamStore.isTest(this)
        if (remaining <= 0) {
            examRunning = true
            endExam("lejárt az idő (újraindítás közben)")
            return
        }
        val gap = (System.currentTimeMillis() - ExamStore.lastSeen(this)) / 1000
        if (gap > 15) {
            ExamStore.appendLog(this, "${ExamStore.stamp()} az app/telefon újraindult (kb. $gap mp-ig nem futott)")
            ExamState.pendingAlarm = true
        }
        ExamState.armedAtMs = System.currentTimeMillis() + ARM_DELAY_MS
        activateExam(remaining, testMode)
    }

    private fun endExam(reason: String) {
        examRunning = false
        ExamState.running = false
        ExamState.onExit = null
        stopService(Intent(this, OverlayService::class.java)) // a riasztást is leállítja
        timer?.cancel()
        try { unregisterReceiver(dndWatcher) } catch (_: Exception) {}
        if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(savedFilter)
        backBlocker.isEnabled = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { stopLockTask() } catch (_: Exception) {}

        val log = ExamStore.log(this)
        ExamStore.clear(this)

        testMode = false
        setBarPad(false)
        timeView.text = ""
        setProfileEditable(true)
        actionBtn.text = "Dolgozat indítása"
        pinInput.hint = "Tanári PIN"
        status.text = "Befejezve ($reason).\n" +
            (if (log.isEmpty()) "Nem volt kilépés." else log.joinToString("\n"))
        menuDialog.show() // a tanár rögtön látja az eredményt és a kilépési naplót
    }

    // Kilépési napló + riasztás: minden alkalommal, amikor az app háttérbe kerül
    override fun onPause() {
        super.onPause()
        ExamState.inForeground = false
        if (examRunning) {
            leftAt = System.currentTimeMillis()
            leftScreenOff = !getSystemService(PowerManager::class.java).isInteractive
            // képernyő-kikapcsolás (power gomb) nem számít kilépésnek, nem riaszt
            if (!leftScreenOff && System.currentTimeMillis() >= ExamState.armedAtMs) {
                lastExitMs = System.currentTimeMillis()
                ExamState.onExit?.invoke()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ExamState.inForeground = true
        if (examRunning && leftAt != 0L) {
            val secs = (System.currentTimeMillis() - leftAt) / 1000
            val what = if (leftScreenOff) "kikapcsolta a képernyőt" else "elhagyta az appot"
            if (System.currentTimeMillis() >= ExamState.armedAtMs || leftScreenOff) {
                ExamStore.appendLog(this, "${ExamStore.stamp()} $what ${secs} mp-re")
            }
            leftAt = 0L
        }
        if (examRunning) {
            if (isInMultiWindowMode) reportExit("osztott képernyőben van")
            relockIfNeeded()
        }
    }

    override fun onDestroy() {
        uiHandler.removeCallbacks(focusCheck)
        timer?.cancel()
        try { unregisterReceiver(dndWatcher) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
