package com.example.examcalc

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * A hálózati állapot ellenőrzése. Android 10 óta egy sima app nem kapcsolhatja
 * a WiFit/mobilnetet, de az állapotot le tudja kérdezni.
 */
object NetCheck {
    const val CELL = "a mobilnet be van kapcsolva"
    const val NO_WIFI = "nincs WiFi kapcsolat"

    /** null = rendben (van WiFi, nincs mobil-adatkapcsolat); különben a probléma leírása. */
    @Suppress("DEPRECATION")
    fun problem(ctx: Context): String? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        var wifi = false
        var cell = false
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) cell = true
        }
        return when {
            cell -> CELL
            !wifi -> NO_WIFI
            else -> null
        }
    }
}
