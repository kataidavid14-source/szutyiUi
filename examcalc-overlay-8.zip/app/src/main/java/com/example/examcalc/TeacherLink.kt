package com.example.examcalc

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import java.net.URI
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.concurrent.thread

/**
 * Kapcsolat a tanári appal (WebSocket a helyi WiFi-n). 3 másodpercenként állapotjelentést küld,
 * és fogadja a tanári "pinget". Újracsatlakozik, ha megszakad.
 */
object TeacherLink {
    private const val PORT = 8765

    private var app: Context? = null
    @Volatile private var running = false
    @Volatile private var ws: WebSocketClient? = null
    @Volatile private var authed = false
    @Volatile private var lastError = ""
    private val main = Handler(Looper.getMainLooper())
    private var pingAlarm: ExitAlarm? = null

    // ---- profil (név, tanári gép címe, kód) ----
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("profile", Context.MODE_PRIVATE)
    fun name(ctx: Context) = prefs(ctx).getString("name", "") ?: ""
    fun host(ctx: Context) = prefs(ctx).getString("host", "") ?: ""
    fun code(ctx: Context) = prefs(ctx).getString("code", "") ?: ""

    fun save(ctx: Context, name: String, host: String, code: String) {
        prefs(ctx).edit().putString("name", name.trim()).putString("host", host.trim())
            .putString("code", code.trim()).apply()
    }

    private fun deviceId(ctx: Context): String {
        val p = prefs(ctx)
        return p.getString("id", null) ?: UUID.randomUUID().toString().also { p.edit().putString("id", it).apply() }
    }

    fun statusText(ctx: Context): String = when {
        name(ctx).isBlank() || host(ctx).isBlank() || code(ctx).isBlank() -> "Nincs beállítva"
        authed -> "Csatlakozva a tanárhoz ✓"
        lastError.isNotEmpty() -> "Nem csatlakozik: $lastError"
        else -> "Csatlakozás…"
    }

    // ---- életciklus ----
    @Synchronized
    fun start(ctx: Context) {
        if (running) return
        app = ctx.applicationContext
        running = true
        thread(name = "teacher-link", isDaemon = true) { loop() }
    }

    /** Új profil mentése után: bontja a jelenlegi kapcsolatot, a ciklus újracsatlakozik. */
    fun reconnect() {
        authed = false
        try { ws?.close() } catch (_: Exception) {}
    }

    private fun loop() {
        val ctx = app ?: return
        while (running) {
            try {
                val name = name(ctx); val host = host(ctx); val code = code(ctx)
                if (name.isBlank() || host.isBlank() || code.isBlank()) {
                    authed = false
                } else {
                    var c = ws
                    if (c == null || !c.isOpen) {
                        authed = false
                        try { c?.close() } catch (_: Exception) {}
                        c = makeClient(ctx, host, code, name)
                        ws = c
                        try {
                            if (!c.connectBlocking(3, TimeUnit.SECONDS)) lastError = "a tanári gép nem érhető el"
                            else lastError = ""
                        } catch (e: Exception) { lastError = e.message ?: "hiba" }
                    }
                    val cur = ws
                    if (cur != null && cur.isOpen && authed) cur.send(stateJson(ctx))
                }
            } catch (e: Exception) { lastError = e.message ?: "hiba" }
            try { Thread.sleep(3_000) } catch (_: InterruptedException) {}
        }
    }

    private fun makeClient(ctx: Context, host: String, code: String, name: String): WebSocketClient {
        val id = deviceId(ctx)
        val client = object : WebSocketClient(URI("ws://$host:$PORT")) {
            override fun onOpen(handshake: ServerHandshake?) {}

            override fun onMessage(message: String?) {
                val j = try { JSONObject(message ?: return) } catch (_: Exception) { return }
                when (j.optString("t")) {
                    "hello" -> {
                        val nonce = j.optString("nonce")
                        send(
                            JSONObject().put("t", "hello").put("id", id).put("name", name)
                                .put("mac", mac(code, nonce + id + name)).toString()
                        )
                    }
                    "ok" -> { authed = true; lastError = "" }
                    "deny" -> { authed = false; lastError = "hibás kód" }
                    "ping" -> main.post { doPing(ctx) }
                }
            }

            override fun onClose(closeCode: Int, reason: String?, remote: Boolean) { authed = false }
            override fun onError(ex: Exception?) { lastError = ex?.message ?: "hiba" }
        }
        client.connectionLostTimeout = 6
        return client
    }

    private fun mac(key: String, data: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key.toByteArray(), "HmacSHA256"))
        return m.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    private fun doPing(ctx: Context) {
        val a = pingAlarm ?: ExitAlarm(ctx).also { pingAlarm = it }
        a.start(5_000)
        Toast.makeText(ctx, "A tanár megpingelte a telefont", Toast.LENGTH_LONG).show()
    }

    private fun stateJson(ctx: Context): String {
        val log = ExamStore.log(ctx)
        val am = ctx.getSystemService(ActivityManager::class.java)
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val left = if (ExamState.running)
            ((ExamState.endAtMs - System.currentTimeMillis()) / 1000).coerceAtLeast(0) else 0L
        return JSONObject()
            .put("t", "st")
            .put("exam", ExamState.running)
            .put("test", ExamState.testMode)
            .put("left", left)
            .put("events", log.size)
            .put("last", log.lastOrNull() ?: "")
            .put("net", NetCheck.problem(ctx) ?: "")
            .put("pinned", am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE)
            .put("bat", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
            .toString()
    }
}
