package com.example.examteacher

import org.java_websocket.WebSocket
import org.json.JSONObject
import java.security.MessageDigest
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class Student(val id: String) {
    @Volatile var name = ""
    @Volatile var conn: WebSocket? = null
    @Volatile var lastSeen = 0L
    @Volatile var exam = false
    @Volatile var test = false
    @Volatile var left = 0L
    @Volatile var events = 0
    @Volatile var last = ""
    @Volatile var net = ""
    @Volatile var pinned = true
    @Volatile var bat = -1
    @Volatile var alerted = false
}

class RosterEntry(val name: String, val ownCalc: Boolean)

/** A kapcsolódott tanulók közös állapota (a szerver írja, a felület és a szolgáltatás olvassa). */
object Hub {
    const val PORT = 8765
    const val OFFLINE_AFTER_MS = 15_000L

    val students = ConcurrentHashMap<String, Student>()
    @Volatile var error = ""

    /** Kisbetű, ékezet nélkül, felesleges szóközök nélkül: "Kiss  Ádám" == "kiss adam". */
    fun norm(s: String): String =
        Normalizer.normalize(s.trim().lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace(Regex("\\s+"), " ")

    /** Soronként egy név; ha a végén * van, a tanulónak saját számológépe van (pl. iPhone). */
    fun parseRoster(text: String): List<RosterEntry> =
        text.lines().map { it.trim() }.filter { it.isNotEmpty() }.map {
            val own = it.endsWith("*")
            RosterEntry(it.removeSuffix("*").trim(), own)
        }

    fun mac(key: String, data: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key.toByteArray(), "HmacSHA256"))
        return m.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun constantEq(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(), b.toByteArray())

    fun hello(id: String, name: String, conn: WebSocket) {
        val st = students.getOrPut(id) { Student(id) }
        st.name = name
        st.conn = conn
        st.lastSeen = System.currentTimeMillis()
        st.alerted = false
    }

    fun disconnected(id: String, conn: WebSocket) {
        students[id]?.let { if (it.conn === conn) it.conn = null }
    }

    fun update(id: String, j: JSONObject) {
        val st = students[id] ?: return
        st.lastSeen = System.currentTimeMillis()
        st.exam = j.optBoolean("exam")
        st.test = j.optBoolean("test")
        st.left = j.optLong("left")
        st.events = j.optInt("events")
        st.last = j.optString("last")
        st.net = j.optString("net")
        st.pinned = j.optBoolean("pinned", true)
        st.bat = j.optInt("bat", -1)
    }

    fun ping(id: String) {
        val c = students[id]?.conn ?: return
        if (c.isOpen) c.send("{\"t\":\"ping\"}")
    }

    fun isOffline(st: Student, now: Long = System.currentTimeMillis()) =
        st.lastSeen > 0 && now - st.lastSeen > OFFLINE_AFTER_MS
}
