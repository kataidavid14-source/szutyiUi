package com.example.examteacher

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    private class RowView(val box: LinearLayout, val title: TextView, val sub: TextView, val btn: Button) {
        var pingId: String? = null
    }

    private class Item(val key: String, val title: String, val sub: String, val color: Int, val pingId: String?)

    private lateinit var prefs: SharedPreferences
    private lateinit var info: TextView
    private lateinit var summary: TextView
    private lateinit var list: LinearLayout
    private lateinit var startBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private var serverOn = false
    private var rowKeys: List<String> = emptyList()
    private val rowViews = HashMap<String, RowView>()
    private var density = 1f

    private val GREEN = Color.parseColor("#C8E6C9")
    private val RED = Color.parseColor("#FFCDD2")
    private val ORANGE = Color.parseColor("#FFE0B2")
    private val PURPLE = Color.parseColor("#E1BEE7")
    private val GREY = Color.parseColor("#ECEFF1")

    private fun px(n: Int) = (n * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        prefs = getSharedPreferences("teacher", MODE_PRIVATE)
        if (prefs.getString("code", "").isNullOrEmpty()) newCode()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val title = TextView(this).apply { text = "Tanári konzol"; textSize = 22f; setTypeface(typeface, Typeface.BOLD) }
        info = TextView(this).apply { textSize = 15f }
        summary = TextView(this).apply { textSize = 15f; setPadding(0, px(6), 0, px(6)) }

        val rosterBtn = Button(this).apply { text = "Névsor"; setOnClickListener { editRoster() } }
        val codeBtn = Button(this).apply {
            text = "Új kód"
            setOnClickListener {
                newCode()
                if (serverOn) startServer() // az új kóddal újraindul; a diákoknak is át kell írniuk
            }
        }
        startBtn = Button(this).apply { text = "Szerver indítása"; setOnClickListener { toggleServer() } }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            addView(rosterBtn, lp()); addView(codeBtn, lp()); addView(startBtn, lp())
        }

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), px(36), px(12), px(8))
            addView(title); addView(info); addView(buttons); addView(summary)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresh)
    }

    private val refresh = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 1_000)
        }
    }

    // ---- szerver ----
    private fun newCode() {
        prefs.edit().putString("code", (100000..999999).random().toString()).apply()
    }

    private fun toggleServer() {
        if (serverOn) {
            stopService(Intent(this, TeacherService::class.java))
            serverOn = false
            startBtn.text = "Szerver indítása"
        } else {
            Hub.students.clear()
            startServer()
        }
    }

    private fun startServer() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, TeacherService::class.java).putExtra("code", prefs.getString("code", ""))
        )
        serverOn = true
        startBtn.text = "Szerver leállítása"
    }

    private fun localAddresses(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { ni ->
            ni.inetAddresses.toList().filter { !it.isLoopbackAddress && it is Inet4Address }
                .map { it.hostAddress ?: "" }
        }.filter { it.isNotEmpty() }
    } catch (_: Exception) { emptyList() }

    // ---- névsor ----
    private fun editRoster() {
        val et = EditText(this).apply {
            setText(prefs.getString("roster", ""))
            hint = "Soronként egy név.\nHa a végére * teszed, saját számológépe van (pl. iPhone)."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_WORDS
            minLines = 8
            gravity = Gravity.TOP
        }
        AlertDialog.Builder(this)
            .setTitle("Névsor")
            .setView(et)
            .setPositiveButton("Mentés") { _, _ -> prefs.edit().putString("roster", et.text.toString()).apply() }
            .setNegativeButton("Mégse", null)
            .show()
    }

    // ---- megjelenítés ----
    private fun describe(st: Student, dup: Boolean, unknown: Boolean, now: Long): Item {
        val age = (now - st.lastSeen) / 1000
        val off = Hub.isOffline(st, now)
        val flags = ArrayList<String>()
        var color = GREEN
        if (off) {
            color = RED
            flags += "OFFLINE ($age mp)"
        } else {
            if (st.net.isNotEmpty()) { color = ORANGE; flags += "hálózat: ${st.net}" }
            if (st.exam && !st.pinned) { color = ORANGE; flags += "nincs képernyő-rögzítés" }
        }
        if (unknown) { if (!off) color = PURPLE; flags += "ISMERETLEN NÉV" }
        if (dup) { if (!off) color = PURPLE; flags += "DUPLA NÉV" }

        val state = if (st.exam)
            (if (st.test) "teszt " else "dolgozat ") + "%d:%02d".format(st.left / 60, st.left % 60)
        else "nincs dolgozat"
        val details = ArrayList<String>()
        details += state
        if (st.bat >= 0) details += "🔋${st.bat}%"
        if (st.events > 0) details += "napló ${st.events}: ${st.last}"
        val sub = (if (flags.isNotEmpty()) flags.joinToString(" · ") + "\n" else "") + details.joinToString(" · ")
        return Item("s:" + st.id, st.name, sub, color, st.id)
    }

    private fun render() {
        val now = System.currentTimeMillis()
        val ips = localAddresses()
        info.text = (if (ips.isEmpty()) "Nincs hálózati cím (kapcsold be a WiFi-t / hotspotot)" else
            "Cím: " + ips.joinToString(" vagy ") { "$it:${Hub.PORT}" }) +
            "\nKód: ${prefs.getString("code", "")}" +
            (if (Hub.error.isNotEmpty()) "\n⚠ ${Hub.error}" else "")

        val roster = Hub.parseRoster(prefs.getString("roster", "") ?: "")
        val students = Hub.students.values.toList()
        val byName = students.groupBy { Hub.norm(it.name) }
        val known = HashSet<String>()
        val items = ArrayList<Item>()

        for (r in roster) {
            val n = Hub.norm(r.name)
            known += n
            val sl = byName[n]
            if (sl.isNullOrEmpty()) {
                items += if (r.ownCalc) Item("r:$n", r.name, "saját számológép (nincs app)", GREY, null)
                else Item("r:$n", r.name, "nem csatlakozott", GREY, null)
            } else {
                for (st in sl) items += describe(st, sl.size > 1, false, now)
            }
        }
        for (st in students.filter { Hub.norm(it.name) !in known }.sortedBy { it.name }) {
            items += describe(st, false, true, now)
        }

        val online = students.count { !Hub.isOffline(it, now) }
        val offline = students.count { Hub.isOffline(it, now) }
        val unknown = students.count { Hub.norm(it.name) !in known }
        summary.text = "Online: $online · Offline: $offline · Ismeretlen: $unknown · Névsor: ${roster.count { !it.ownCalc }} fő"

        // Csak akkor építjük újra a sorokat, ha a lista elemei változtak (így nem vész el koppintás).
        val keys = items.map { it.key }
        if (keys != rowKeys) {
            list.removeAllViews()
            rowViews.clear()
            for (it in items) {
                val rv = makeRow()
                rowViews[it.key] = rv
                list.addView(rv.box)
            }
            rowKeys = keys
        }
        for (it in items) {
            val rv = rowViews[it.key] ?: continue
            rv.title.text = it.title
            rv.sub.text = it.sub
            rv.pingId = it.pingId
            rv.btn.visibility = if (it.pingId != null) android.view.View.VISIBLE else android.view.View.GONE
            rv.box.background = GradientDrawable().apply { setColor(it.color); cornerRadius = px(10).toFloat() }
        }
    }

    private fun makeRow(): RowView {
        val title = TextView(this).apply { textSize = 17f; setTypeface(typeface, Typeface.BOLD) }
        val sub = TextView(this).apply { textSize = 13f }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(title); addView(sub) }
        val btn = Button(this).apply {
            text = "📣"
            minWidth = 0; minimumWidth = 0
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(12), px(8), px(8), px(8))
            addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn, LinearLayout.LayoutParams(px(56), px(48)))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = px(6) }
        }
        val rv = RowView(box, title, sub, btn)
        btn.setOnClickListener {
            rv.pingId?.let {
                Hub.ping(it)
                Toast.makeText(this, "Ping elküldve", Toast.LENGTH_SHORT).show()
            }
        }
        return rv
    }
}
