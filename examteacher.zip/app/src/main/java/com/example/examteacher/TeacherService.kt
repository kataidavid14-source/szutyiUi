package com.example.examteacher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** WebSocket-szerver: a diákok telefonjai ide jelentkeznek (kód alapján hitelesítve). */
class HubServer(private val code: String) : WebSocketServer(InetSocketAddress(Hub.PORT)) {
    private val nonces = ConcurrentHashMap<WebSocket, String>()
    private val authed = ConcurrentHashMap<WebSocket, String>()

    override fun onOpen(conn: WebSocket, handshake: ClientHandshake?) {
        val nonce = UUID.randomUUID().toString().replace("-", "")
        nonces[conn] = nonce
        conn.send(JSONObject().put("t", "hello").put("nonce", nonce).toString())
    }

    override fun onClose(conn: WebSocket, closeCode: Int, reason: String?, remote: Boolean) {
        nonces.remove(conn)
        authed.remove(conn)?.let { Hub.disconnected(it, conn) }
    }

    override fun onMessage(conn: WebSocket, message: String?) {
        val j = try { JSONObject(message ?: return) } catch (_: Exception) { return }
        when (j.optString("t")) {
            "hello" -> {
                val id = j.optString("id")
                val name = j.optString("name")
                val nonce = nonces[conn] ?: return
                val ok = id.isNotEmpty() && name.isNotEmpty() &&
                    Hub.constantEq(Hub.mac(code, nonce + id + name), j.optString("mac"))
                if (ok) {
                    authed[conn] = id
                    Hub.hello(id, name, conn)
                    conn.send("{\"t\":\"ok\"}")
                } else {
                    conn.send("{\"t\":\"deny\"}")
                    conn.close()
                }
            }
            "st" -> authed[conn]?.let { Hub.update(it, j) }
        }
    }

    override fun onError(conn: WebSocket?, ex: Exception?) {
        if (conn == null) Hub.error = ex?.message ?: "szerverhiba"
    }

    override fun onStart() {
        connectionLostTimeout = 10
        Hub.error = ""
    }
}

/**
 * Előtér-szolgáltatás: a szerver akkor is fut, ha a képernyő kikapcsol.
 * Offline tanulónál értesítést + rezgést ad (NEM ébresztő-csatornán, így nem nyomja el a CGM riasztásait).
 */
class TeacherService : Service() {
    private var server: HubServer? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            for (st in Hub.students.values) {
                val off = Hub.isOffline(st, now)
                if (off && !st.alerted) { st.alerted = true; alertOffline(st) }
                else if (!off) st.alerted = false
            }
            handler.postDelayed(this, 1_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("server", "Szerver", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(
            NotificationChannel("alerts", "Offline riasztás", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
            }
        )
        startForeground(
            1,
            Notification.Builder(this, "server")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentTitle("Tanári szerver fut")
                .setContentIntent(openApp())
                .setOngoing(true)
                .build()
        )
        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "examteacher:server").apply { acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getStringExtra("code")
            ?: getSharedPreferences("teacher", MODE_PRIVATE).getString("code", "") ?: ""
        try { server?.stop(500) } catch (_: Exception) {}
        server = HubServer(code).also {
            it.isReuseAddr = true
            it.start()
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun alertOffline(st: Student) {
        val n = Notification.Builder(this, "alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⚠ OFFLINE: ${st.name}")
            .setContentText("Vedd el a telefont, és ellenőrizd!")
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(st.id.hashCode(), n)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { server?.stop(500) } catch (_: Exception) {}
        server = null
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
