# SzutyiUI Launcher

A real Android home-screen launcher. Registers for the `HOME` intent, reads
real installed apps via `PackageManager`, and includes a visual-polish pass:
spring-based drawer motion, press-bounce icons, ambient glow wallpaper, a
pulsing swipe hint, an animated clock entrance, and a real battery percentage
in the status bar.

## Building via GitHub Actions (no computer needed)
This repo's workflow expects the source as a single zip at the repo root
(since mobile file pickers can't upload a folder tree):
1. Create the workflow file directly on GitHub at
   `.github/workflows/build-apk.yml` (paste in its contents).
2. Upload the flat source zip (no wrapping folder) to the repo root via
   **Add file → Upload files**.
3. **Actions** tab → the workflow runs automatically, unzips the source,
   and builds a debug APK with Gradle 8.9 (pinned to match AGP 8.5.2).
4. Open the run → **Artifacts** → download the APK → install it.

## Setting it as your default launcher
Press Home after installing — Android will offer a chooser. Pick SzutyiUI
and "Always". To switch later: **Settings → Apps → Default apps → Home app**.

## Project layout
```
app/src/main/java/com/szutyi/launcher/
├── MainActivity.kt      # UI: status bar, clock, dock, drawer, search, long-press menu
├── AppRepository.kt     # PackageManager queries (list/launch/info/uninstall)
├── AppInfo.kt           # data class for one installed app
└── Theme.kt             # dark Compose color scheme
```
