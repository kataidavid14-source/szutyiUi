# SzutyiUI Launcher

A real Android home-screen launcher — not a mockup. It registers for the
`HOME` intent, so once installed, Android will offer it in the "Select
Home app" chooser alongside your stock launcher.

## What it does
- **Home screen**: live clock + date, a 5-app dock, swipe-up hint.
- **App drawer**: swipe up from anywhere on the home screen to see every
  installed app, with a live search filter. Swipe down (or press Back)
  to close it.
- **Real app data**: the app list, icons, and labels come straight from
  `PackageManager` — nothing is hardcoded.
- **Long-press** any icon (dock or drawer) for **App info** or
  **Uninstall**, same as a normal launcher.
- Pressing Home again while already in SzutyiUI snaps you back to the
  home screen and closes the drawer/search.

## Requirements
- Android Studio (Koala/2024.1 or newer)
- JDK 17 (bundled with recent Android Studio)
- A device or emulator running Android 8.0 (API 26) or later

## Building from a phone (no computer)
Android Studio has no mobile version, but you don't need it: this repo
includes `.github/workflows/build-apk.yml`, which builds the APK on
GitHub's servers.

1. Create a new GitHub repo and get this project's files into it — the
   easiest way from a phone is the **Termux** app: `pkg install git`,
   then `git init`, `git add .`, `git commit`, and `git push` to a repo
   you created on github.com (you'll need a personal access token as
   the password).
2. Once pushed, open the repo on github.com in your phone's browser →
   **Actions** tab → the "Build APK" workflow will already have run
   (or tap "Run workflow" to trigger it).
3. Open the finished run → scroll to **Artifacts** → download
   `SzutyiUI-debug-apk`. It's a zip containing the installable `.apk`.
4. Open the downloaded `.apk` on your phone to install it (you'll need
   to allow "install unknown apps" for your browser/file manager once).

## Build & run (on a computer)
1. Open the `SzutyiUI-Launcher` folder in Android Studio as a project
   ("Open" → select this folder — it will detect `settings.gradle.kts`).
2. Let Gradle sync (first sync downloads the Compose/AGP dependencies).
3. Press **Run** with a device/emulator selected, or
   **Build → Build Bundle(s)/APK(s) → Build APK(s)** to get an installable
   `.apk` under `app/build/outputs/apk/debug/`.

## Setting it as your default launcher
After installing, press the device's **Home** button:
- If this is the only extra launcher installed, Android asks you to pick
  one and offers "Always" / "Just once" — pick SzutyiUI + Always.
- To switch back or change your mind later: **Settings → Apps → Default
  apps → Home app** (path varies slightly by Android skin/version).

## Notes & current limitations
- `QUERY_ALL_PACKAGES` is declared in the manifest so the drawer can see
  every launchable app on Android 11+. That's fine for a personal/sideloaded
  build; a Play Store release of a *non-launcher* app would need to justify
  that permission, but launcher apps are exempt from that review requirement.
- No home-screen widgets, wallpaper picker, or drag-to-rearrange icons yet —
  the home screen is intentionally just clock + dock, with everything else
  one swipe away in the drawer. All of that is addable later; the
  `AppRepository` and Compose UI are split into separate files so it's easy
  to extend.
- No app icon asset is bundled (`android:icon` points at a stock system
  icon) — drop your own into `app/src/main/res/mipmap-*` and update
  `AndroidManifest.xml` if you want custom branding on the installed APK
  itself.

## Project layout
```
SzutyiUI-Launcher/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/values/strings.xml
        └── java/com/szutyi/launcher/
            ├── MainActivity.kt      # UI: clock, dock, drawer, search, long-press menu
            ├── AppRepository.kt     # PackageManager queries (list/launch/info/uninstall)
            ├── AppInfo.kt           # data class for one installed app
            └── Theme.kt             # dark Compose color scheme
```
