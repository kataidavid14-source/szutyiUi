package com.szutyi.launcher

import android.graphics.drawable.Drawable

/** One installed, launchable app. */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)
