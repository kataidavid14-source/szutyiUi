package com.szutyi.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings

/**
 * Everything that talks to PackageManager: listing installed apps,
 * launching them, and the long-press actions (app info / uninstall).
 */
object AppRepository {

    fun getLaunchableApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)

        return resolveInfos
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .map { ri ->
                val installTime = runCatching {
                    pm.getPackageInfo(ri.activityInfo.packageName, 0).firstInstallTime
                }.getOrDefault(0L)
                AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    packageName = ri.activityInfo.packageName,
                    activityName = ri.activityInfo.name,
                    icon = ri.loadIcon(pm),
                    firstInstallTime = installTime
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    /** Reorders an already-fetched app list according to the user's chosen sort order. */
    fun sortApps(apps: List<AppInfo>, order: AppSortOrder): List<AppInfo> = when (order) {
        AppSortOrder.NAME_ASC -> apps.sortedBy { it.label.lowercase() }
        AppSortOrder.NAME_DESC -> apps.sortedByDescending { it.label.lowercase() }
        AppSortOrder.RECENTLY_INSTALLED -> apps.sortedByDescending { it.firstInstallTime }
    }

    fun launch(context: Context, app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun openAppInfo(context: Context, app: AppInfo) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", app.packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun uninstall(context: Context, app: AppInfo) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.fromParts("package", app.packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
