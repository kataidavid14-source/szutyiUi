package com.szutyi.launcher

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * A translucent "liquid glass" panel, in the style of iOS 26 / visionOS
 * frosted surfaces: a soft tinted gradient fill, a light-catching gradient
 * border, a specular highlight along the top edge, and a slow diagonal sheen
 * that drifts across the surface like light moving through glass.
 *
 * There's no literal backdrop blur sampled from what's behind it here (real
 * backdrop blur needs RenderEffect, API 31+, plus capturing the layer behind
 * this composable) - this fakes the look with layered translucency instead.
 * It reads convincingly against the launcher's own gradient wallpaper and is
 * far cheaper to run on every frame.
 *
 * [backdropColor] lets a caller give the glass an opaque-ish backing (e.g.
 * for a settings sheet that needs to stay legible) while still getting the
 * sheen/border treatment on top. [glowColor]/[glowAlpha] adds a second,
 * colored border on top of the base one - used for focus/accent highlights.
 */
@Composable
fun LiquidGlass(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    backdropColor: Color = Color.Transparent,
    tint: Color = Color.White,
    baseAlpha: Float = 0.16f,
    glowColor: Color = Color.White,
    glowAlpha: Float = 0f,
    content: @Composable BoxWithConstraintsScope.() -> Unit
) {
    var glassModifier = modifier
        .clip(shape)
        .background(backdropColor)
        .background(
            Brush.verticalGradient(
                colors = listOf(
                    tint.copy(alpha = baseAlpha + 0.10f),
                    tint.copy(alpha = baseAlpha),
                    tint.copy(alpha = baseAlpha * 0.55f)
                )
            )
        )
        .border(
            width = 1.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.55f),
                    Color.White.copy(alpha = 0.06f),
                    Color.White.copy(alpha = 0.28f)
                )
            ),
            shape = shape
        )
    if (glowAlpha > 0f) {
        glassModifier = glassModifier.border(1.dp, glowColor.copy(alpha = glowAlpha), shape)
    }

    BoxWithConstraints(modifier = glassModifier) {
        val infiniteTransition = rememberInfiniteTransition(label = "glassSheen")
        val sheenOffset by infiniteTransition.animateFloat(
            initialValue = -1.3f,
            targetValue = 1.3f,
            animationSpec = infiniteRepeatable(
                animation = tween(5200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "sheenOffset"
        )
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.14f),
                            Color.Transparent
                        ),
                        start = Offset(sheenOffset * widthPx - widthPx * 0.4f, 0f),
                        end = Offset(sheenOffset * widthPx + widthPx * 0.4f, heightPx)
                    )
                )
        )
        // specular highlight along the very top edge
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .align(Alignment.TopCenter)
                .background(Color.White.copy(alpha = 0.5f))
        )
        content()
    }
}
