package com.szutyi.launcher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

/**
 * SzutyiUI Launcher
 *
 * A real Android home-screen replacement:
 *  - registers for the HOME intent, so Android offers it as a launcher choice
 *  - reads the real list of installed apps via PackageManager
 *  - home screen = clock + dock; swipe up = full searchable app drawer
 *  - long-press an icon for App info / Uninstall
 *
 * Visual-polish pass: spring-based drawer motion with a parallaxing home
 * layer, press-driven icon bounce, a soft ambient glow behind the
 * wallpaper, a pulsing swipe hint, an animated clock entrance, and a real
 * (not fake) battery percentage in the status bar.
 */
class MainActivity : ComponentActivity() {

    private val homeSignal = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SzutyiLauncherTheme {
                LauncherRoot(homeSignal = homeSignal.value)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        homeSignal.value++
    }
}

@Composable
fun LauncherRoot(homeSignal: Int) {
    val context = LocalContext.current

    var drawerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var contextMenuApp by remember { mutableStateOf<AppInfo?>(null) }

    val allApps = remember { AppRepository.getLaunchableApps(context) }
    val dockApps = remember(allApps) { allApps.take(5) }

    LaunchedEffect(homeSignal) {
        drawerOpen = false
        query = ""
    }

    BackHandler(enabled = drawerOpen) { drawerOpen = false }

    // 0f = fully closed, 1f = fully open. A bouncy spring instead of a flat
    // tween makes the drawer feel like it has real weight to it.
    val drawerProgress by animateFloatAsState(
        targetValue = if (drawerOpen) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "drawerProgress"
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0916))
    ) {
        // ---------------- AMBIENT WALLPAPER ----------------
        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0xFF2A1F4D), Color(0xFF14233A), Color(0xFF0D0916))
                        )
                    )
            )
            // soft glow orbs for depth - purely decorative, degrade gracefully
            // (no-op blur) on pre-Android-12 devices
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.TopStart)
                    .offset(x = (-60).dp, y = 40.dp)
                    .blur(90.dp)
                    .background(Color(0xFF3DDAD7).copy(alpha = 0.28f), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(300.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = 70.dp, y = 90.dp)
                    .blur(100.dp)
                    .background(Color(0xFFFF5EA8).copy(alpha = 0.22f), CircleShape)
            )
        }

        // ---------------- HOME LAYER (parallax: dims/scales as drawer opens) ----------------
        val homeDepth = 1f - drawerProgress
        val homeScale = 0.95f + 0.05f * homeDepth
        val homeAlpha = 0.7f + 0.3f * homeDepth
        Column(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(scaleX = homeScale, scaleY = homeScale, alpha = homeAlpha)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount < -14) drawerOpen = true
                    }
                }
        ) {
            StatusBar(context)
            Spacer(Modifier.height(48.dp))
            ClockBlock()
            Spacer(Modifier.weight(1f))
            Dock(
                apps = dockApps,
                onTap = { AppRepository.launch(context, it) },
                onLongPress = { contextMenuApp = it }
            )
            Spacer(Modifier.height(22.dp))
            SwipeHandle()
            Spacer(Modifier.height(14.dp))
        }

        // ---------------- APP DRAWER LAYER ----------------
        val drawerOffset = maxHeight * (1f - drawerProgress)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = drawerOffset)
                .background(Color(0xFF0A0712).copy(alpha = 0.92f))
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount > 14) drawerOpen = false
                    }
                }
        ) {
            Spacer(Modifier.height(56.dp))
            SearchField(value = query, onChange = { query = it })
            Spacer(Modifier.height(18.dp))
            val filtered = remember(allApps, query) {
                if (query.isBlank()) allApps
                else allApps.filter { it.label.contains(query, ignoreCase = true) }
            }
            AppGrid(
                apps = filtered,
                onTap = { AppRepository.launch(context, it) },
                onLongPress = { contextMenuApp = it },
                modifier = Modifier.weight(1f)
            )
        }
    }

    contextMenuApp?.let { app ->
        AppContextMenu(
            app = app,
            onDismiss = { contextMenuApp = null },
            onInfo = {
                AppRepository.openAppInfo(context, app)
                contextMenuApp = null
            },
            onUninstall = {
                AppRepository.uninstall(context, app)
                contextMenuApp = null
            }
        )
    }
}

@Composable
private fun StatusBar(context: Context) {
    val batteryPercent = rememberBatteryLevel(context)
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }
    val sbFmt = remember { SimpleDateFormat("h:mm", Locale.getDefault()) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 26.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = sbFmt.format(now),
            color = Color(0xFFF5F2FF),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (batteryPercent >= 0) {
                Text(
                    text = "$batteryPercent%",
                    color = Color(0xFFB8AED6),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
            BatteryGlyph(percent = batteryPercent)
        }
    }
}

@Composable
private fun rememberBatteryLevel(context: Context): Int {
    var level by remember { mutableStateOf(-1) }
    LaunchedEffect(Unit) {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawLevel = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        level = if (rawLevel >= 0 && scale > 0) (rawLevel * 100 / scale) else -1
    }
    return level
}

@Composable
private fun BatteryGlyph(percent: Int) {
    val fillFraction = (percent.coerceIn(0, 100) / 100f)
    Box(
        modifier = Modifier
            .width(22.dp)
            .height(11.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0x33FFFFFF))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(if (percent >= 0) fillFraction else 1f)
                .background(
                    if (percent in 0..15) Color(0xFFFF5E5E) else Color(0xFFF5F2FF)
                )
        )
    }
}

@Composable
private fun ClockBlock() {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }
    val timeFmt = remember { SimpleDateFormat("h:mm", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()) }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(500)) + slideInVertically(
            animationSpec = tween(500),
            initialOffsetY = { -it / 3 }
        )
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = timeFmt.format(now),
                color = Color(0xFFF5F2FF),
                fontSize = 68.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = dateFmt.format(now),
                color = Color(0xFFB8AED6),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(16.dp))
            Surface(shape = RoundedCornerShape(50), color = Color(0x1AFFFFFF)) {
                Text(
                    text = "  SzutyiUI  ",
                    modifier = Modifier.padding(vertical = 7.dp),
                    color = Color(0xFFF5F2FF),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/** A tap target that bounces on press - shared by the dock and the drawer grid. */
@Composable
private fun AppIconButton(
    app: AppInfo,
    size: Int = 56,
    showLabel: Boolean = false,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "iconScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .padding(4.dp)
            .pointerInput(app.packageName) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onTap(app) },
                    onLongPress = { onLongPress(app) }
                )
            }
    ) {
        val bitmap = remember(app.packageName) {
            app.icon.toBitmap(width = 144, height = 144).asImageBitmap()
        }
        Image(
            bitmap = bitmap,
            contentDescription = app.label,
            modifier = Modifier
                .size(size.dp)
                .scale(scale)
                .clip(RoundedCornerShape(18.dp))
        )
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = app.label,
                color = Color(0xFFB8AED6),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Dock(
    apps: List<AppInfo>,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = Color(0x1FFFFFFF),
        shadowElevation = 12.dp,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            apps.forEach { app ->
                AppIconButton(app = app, onTap = onTap, onLongPress = onLongPress)
            }
        }
    }
}

@Composable
private fun SwipeHandle() {
    val infiniteTransition = rememberInfiniteTransition(label = "swipeHint")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "handleAlpha"
    )
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .width(120.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = alpha))
        )
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val borderAlpha by animateFloatAsState(if (focused) 0.5f else 0f, label = "searchBorder")

    Surface(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(50),
        color = Color(0x1AFFFFFF),
        border = BorderStroke(1.dp, Color(0xFF3DDAD7).copy(alpha = borderAlpha))
    ) {
        Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                cursorBrush = SolidColor(Color(0xFF3DDAD7)),
                modifier = Modifier.onFocusChanged { focused = it.isFocused },
                decorationBox = { innerField ->
                    if (value.isEmpty()) {
                        Text("Search apps", color = Color(0xFF7A6F99), fontSize = 14.sp)
                    }
                    innerField()
                }
            )
        }
    }
}

@Composable
private fun AppGrid(
    apps: List<AppInfo>,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = modifier.padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(apps, key = { it.packageName }) { app ->
            AppIconButton(app = app, showLabel = true, onTap = onTap, onLongPress = onLongPress)
        }
    }
}

@Composable
private fun AppContextMenu(
    app: AppInfo,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(app.label) },
        text = { Text("Choose an action for this app.") },
        confirmButton = {
            TextButton(onClick = onInfo) { Text("App info") }
        },
        dismissButton = {
            TextButton(onClick = onUninstall) { Text("Uninstall") }
        }
    )
}
