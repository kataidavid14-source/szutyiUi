package com.szutyi.launcher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

/**
 * SzutyiUI Launcher
 *
 * A real Android home-screen replacement:
 *  - registers for the HOME intent, so Android offers it as a launcher choice
 *  - reads the real list of installed apps via PackageManager
 *  - home screen = clock + dock; swipe up = full searchable app drawer
 *  - long-press an icon for App info / Uninstall
 *  - gear icon in the status bar opens a settings panel: accent color,
 *    24-hour clock, dock labels, and which apps sit in the dock - all
 *    persisted via SharedPreferences (SettingsRepository)
 */
class MainActivity : ComponentActivity() {

    private val homeSignal = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemStatusBar()
        setContent {
            SzutyiLauncherTheme {
                LauncherRoot(homeSignal = homeSignal.value)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // re-hide whenever the launcher regains focus (e.g. after the
        // notification shade closes, or coming back from another app)
        if (hasFocus) hideSystemStatusBar()
    }

    private fun hideSystemStatusBar() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.statusBars())
        // lets the user still swipe down from the top to peek the real
        // status bar / notification shade; it re-hides on its own after
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        homeSignal.value++
    }
}

@Composable
fun LauncherRoot(homeSignal: Int) {
    val context = LocalContext.current

    var drawerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var contextMenuApp by remember { mutableStateOf<AppInfo?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var dockPickerOpen by remember { mutableStateOf(false) }
    var folderEditorOpen by remember { mutableStateOf(false) }
    var editingFolder by remember { mutableStateOf<Folder?>(null) } // null while folderEditorOpen == creating new
    var openFolder by remember { mutableStateOf<Folder?>(null) }    // folder currently shown full-screen

    var accentIndex by remember { mutableStateOf(SettingsRepository.getAccentIndex(context)) }
    var use24Hour by remember { mutableStateOf(SettingsRepository.getUse24Hour(context)) }
    var showDockLabels by remember { mutableStateOf(SettingsRepository.getShowDockLabels(context)) }
    var dockPackages by remember { mutableStateOf(SettingsRepository.getDockPackages(context)) }
    var folders by remember { mutableStateOf(SettingsRepository.getFolders(context)) }
    val accentColor = ACCENTS[accentIndex].color

    val allApps = remember { AppRepository.getLaunchableApps(context) }
    val dockApps = remember(allApps, dockPackages) {
        if (dockPackages.isEmpty()) allApps.take(5)
        else allApps.filter { dockPackages.contains(it.packageName) }
            .ifEmpty { allApps.take(5) }
    }

    fun folderApps(folder: Folder) = allApps.filter { folder.packages.contains(it.packageName) }

    LaunchedEffect(homeSignal) {
        drawerOpen = false
        query = ""
        settingsOpen = false
        dockPickerOpen = false
        folderEditorOpen = false
        openFolder = null
    }

    BackHandler(enabled = dockPickerOpen) { dockPickerOpen = false }
    BackHandler(enabled = folderEditorOpen && !dockPickerOpen) { folderEditorOpen = false }
    BackHandler(enabled = settingsOpen && !dockPickerOpen && !folderEditorOpen) { settingsOpen = false }
    BackHandler(enabled = openFolder != null) { openFolder = null }
    BackHandler(enabled = drawerOpen && !settingsOpen && openFolder == null) { drawerOpen = false }

    val drawerProgress by animateFloatAsState(
        targetValue = if (drawerOpen) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "drawerProgress"
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0916))
    ) {
        // ---------------- AMBIENT WALLPAPER ----------------
        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0xFF2A1F4D), Color(0xFF14233A), Color(0xFF0D0916))
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.TopStart)
                    .offset(x = (-60).dp, y = 40.dp)
                    .blur(90.dp)
                    .background(accentColor.copy(alpha = 0.28f), CircleShape)
            )
            Box(
                modifier = Modifier
                    .size(300.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = 70.dp, y = 90.dp)
                    .blur(100.dp)
                    .background(Color(0xFFFF5EA8).copy(alpha = 0.22f), CircleShape)
            )
        }

        // ---------------- HOME LAYER ----------------
        val homeDepth = 1f - drawerProgress
        val homeScale = 0.95f + 0.05f * homeDepth
        val homeAlpha = 0.7f + 0.3f * homeDepth
        Column(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(scaleX = homeScale, scaleY = homeScale, alpha = homeAlpha)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount < -14) drawerOpen = true
                    }
                }
        ) {
            StatusBar(context = context, use24Hour = use24Hour, onSettingsClick = { settingsOpen = true })
            Spacer(Modifier.height(48.dp))
            ClockBlock(use24Hour = use24Hour)
            if (folders.isNotEmpty()) {
                Spacer(Modifier.height(28.dp))
                FolderRow(
                    folders = folders,
                    appsFor = { folderApps(it) },
                    onOpen = { openFolder = it }
                )
            }
            Spacer(Modifier.weight(1f))
            Dock(
                apps = dockApps,
                showLabels = showDockLabels,
                onTap = { AppRepository.launch(context, it) },
                onLongPress = { contextMenuApp = it }
            )
            Spacer(Modifier.height(22.dp))
            SwipeHandle(accentColor = accentColor)
            Spacer(Modifier.height(14.dp))
        }

        // ---------------- APP DRAWER LAYER ----------------
        val drawerOffset = maxHeight * (1f - drawerProgress)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = drawerOffset)
                .background(Color(0xFF0A0712).copy(alpha = 0.92f))
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount > 14) drawerOpen = false
                    }
                }
        ) {
            Spacer(Modifier.height(56.dp))
            SearchField(value = query, onChange = { query = it }, accentColor = accentColor)
            Spacer(Modifier.height(18.dp))
            val filtered = remember(allApps, query) {
                if (query.isBlank()) allApps
                else allApps.filter { it.label.contains(query, ignoreCase = true) }
            }
            AppGrid(
                apps = filtered,
                onTap = { AppRepository.launch(context, it) },
                onLongPress = { contextMenuApp = it },
                modifier = Modifier.weight(1f)
            )
        }

        // ---------------- SETTINGS OVERLAY ----------------
        if (settingsOpen && !dockPickerOpen && !folderEditorOpen) {
            SettingsOverlay(
                accentIndex = accentIndex,
                onAccentChange = {
                    accentIndex = it
                    SettingsRepository.setAccentIndex(context, it)
                },
                use24Hour = use24Hour,
                onUse24HourChange = {
                    use24Hour = it
                    SettingsRepository.setUse24Hour(context, it)
                },
                showDockLabels = showDockLabels,
                onShowDockLabelsChange = {
                    showDockLabels = it
                    SettingsRepository.setShowDockLabels(context, it)
                },
                onEditDock = { dockPickerOpen = true },
                folders = folders,
                onNewFolder = {
                    editingFolder = null
                    folderEditorOpen = true
                },
                onEditFolder = {
                    editingFolder = it
                    folderEditorOpen = true
                },
                onDeleteFolder = { toDelete ->
                    val updated = folders.filterNot { it.id == toDelete.id }
                    folders = updated
                    SettingsRepository.setFolders(context, updated)
                    if (openFolder?.id == toDelete.id) openFolder = null
                },
                onDismiss = { settingsOpen = false }
            )
        }

        // ---------------- DOCK PICKER OVERLAY ----------------
        if (dockPickerOpen) {
            DockPickerOverlay(
                allApps = allApps,
                selected = dockPackages,
                accentColor = accentColor,
                onToggle = { pkg ->
                    val current = dockPackages.toMutableList()
                    if (current.contains(pkg)) current.remove(pkg)
                    else if (current.size < 5) current.add(pkg)
                    dockPackages = current
                    SettingsRepository.setDockPackages(context, current)
                },
                onDone = { dockPickerOpen = false }
            )
        }

        // ---------------- FOLDER EDITOR OVERLAY ----------------
        if (folderEditorOpen) {
            FolderEditorOverlay(
                allApps = allApps,
                editingFolder = editingFolder,
                accentColor = accentColor,
                onSave = { name, packages ->
                    val id = editingFolder?.id ?: UUID.randomUUID().toString()
                    val updated = folders.filterNot { it.id == id } + Folder(id, name, packages)
                    folders = updated
                    SettingsRepository.setFolders(context, updated)
                    if (openFolder?.id == id) openFolder = updated.first { it.id == id }
                    folderEditorOpen = false
                },
                onDelete = editingFolder?.let { toDelete ->
                    {
                        val updated = folders.filterNot { it.id == toDelete.id }
                        folders = updated
                        SettingsRepository.setFolders(context, updated)
                        if (openFolder?.id == toDelete.id) openFolder = null
                        folderEditorOpen = false
                    }
                },
                onCancel = { folderEditorOpen = false }
            )
        }

        // ---------------- FOLDER CONTENTS OVERLAY ----------------
        openFolder?.let { folder ->
            FolderContentsOverlay(
                folder = folder,
                apps = folderApps(folder),
                onDismiss = { openFolder = null },
                onEdit = {
                    editingFolder = folder
                    folderEditorOpen = true
                },
                onTapApp = { AppRepository.launch(context, it) },
                onLongPressApp = { contextMenuApp = it }
            )
        }
    }

    contextMenuApp?.let { app ->
        AppContextMenu(
            app = app,
            onDismiss = { contextMenuApp = null },
            onInfo = {
                AppRepository.openAppInfo(context, app)
                contextMenuApp = null
            },
            onUninstall = {
                AppRepository.uninstall(context, app)
                contextMenuApp = null
            }
        )
    }
}

@Composable
private fun StatusBar(context: Context, use24Hour: Boolean, onSettingsClick: () -> Unit) {
    val batteryPercent = rememberBatteryLevel(context)
    val isSilent = rememberSilentMode(context)
    val netState = rememberNetworkState(context)
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }
    val sbFmt = remember(use24Hour) {
        SimpleDateFormat(if (use24Hour) "HH:mm" else "h:mm", Locale.getDefault())
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 26.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = sbFmt.format(now),
            color = Color(0xFFF5F2FF),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            if (isSilent) MuteGlyph()
            WifiGlyph(active = netState == NetState.WIFI)
            CellularGlyph(active = netState == NetState.CELLULAR)
            if (batteryPercent >= 0) {
                Text(
                    text = "$batteryPercent%",
                    color = Color(0xFFB8AED6),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            BatteryGlyph(percent = batteryPercent)
            Spacer(Modifier.width(6.dp))
            Text(
                text = "\u2699",
                color = Color(0xFFB8AED6),
                fontSize = 15.sp,
                modifier = Modifier.pointerInput(Unit) {
                    detectTapGestures(onTap = { onSettingsClick() })
                }
            )
        }
    }
}

/** True while the ringer is on silent or vibrate - the "Do Not Disturb"-style glyph. */
@Composable
private fun rememberSilentMode(context: Context): Boolean {
    var silent by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        while (true) {
            silent = runCatching { audioManager?.ringerMode != AudioManager.RINGER_MODE_NORMAL }
                .getOrDefault(false)
            delay(5_000)
        }
    }
    return silent
}

private enum class NetState { WIFI, CELLULAR, NONE }

/** Which transport the active network is currently using, polled every few seconds. */
@Composable
private fun rememberNetworkState(context: Context): NetState {
    var state by remember { mutableStateOf(NetState.NONE) }
    LaunchedEffect(Unit) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        while (true) {
            state = runCatching {
                val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
                when {
                    caps == null -> NetState.NONE
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetState.WIFI
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetState.CELLULAR
                    else -> NetState.NONE
                }
            }.getOrDefault(NetState.NONE)
            delay(5_000)
        }
    }
    return state
}

/** Speaker-with-a-slash glyph, shown only while the ringer is silenced. */
@Composable
private fun MuteGlyph() {
    val color = Color(0xFFFF8A3D)
    Canvas(modifier = Modifier.size(15.dp)) {
        val w = size.width
        val h = size.height
        val cone = Path().apply {
            moveTo(w * 0.06f, h * 0.36f)
            lineTo(w * 0.30f, h * 0.36f)
            lineTo(w * 0.56f, h * 0.12f)
            lineTo(w * 0.56f, h * 0.88f)
            lineTo(w * 0.30f, h * 0.64f)
            lineTo(w * 0.06f, h * 0.64f)
            close()
        }
        drawPath(cone, color = color)
        drawLine(
            color = color,
            start = Offset(w * 0.08f, h * 0.08f),
            end = Offset(w * 0.94f, h * 0.92f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

/** Three nested arcs + a dot - a plain WiFi glyph, dimmed when not connected over WiFi. */
@Composable
private fun WifiGlyph(active: Boolean) {
    val color = if (active) Color(0xFFF5F2FF) else Color(0x3DFFFFFF)
    Canvas(modifier = Modifier.size(15.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
        drawArc(
            color = color,
            startAngle = 215f,
            sweepAngle = 110f,
            useCenter = false,
            topLeft = Offset(w * 0.0f, h * -0.2f),
            size = Size(w, w),
            style = stroke
        )
        drawArc(
            color = color,
            startAngle = 215f,
            sweepAngle = 110f,
            useCenter = false,
            topLeft = Offset(w * 0.18f, h * 0.02f),
            size = Size(w * 0.64f, w * 0.64f),
            style = stroke
        )
        drawArc(
            color = color,
            startAngle = 215f,
            sweepAngle = 110f,
            useCenter = false,
            topLeft = Offset(w * 0.36f, h * 0.24f),
            size = Size(w * 0.28f, w * 0.28f),
            style = stroke
        )
        drawCircle(color = color, radius = w * 0.08f, center = Offset(w * 0.5f, h * 0.86f))
    }
}

/** Four ascending bars - a plain mobile-signal glyph, dimmed when not on cellular. */
@Composable
private fun CellularGlyph(active: Boolean) {
    val color = if (active) Color(0xFFF5F2FF) else Color(0x3DFFFFFF)
    Canvas(modifier = Modifier.size(15.dp)) {
        val barCount = 4
        val gap = size.width * 0.10f
        val barWidth = (size.width - gap * (barCount - 1)) / barCount
        val heights = listOf(0.35f, 0.55f, 0.75f, 1f)
        heights.forEachIndexed { i, frac ->
            val barHeight = size.height * frac
            drawRoundRect(
                color = color,
                topLeft = Offset(i * (barWidth + gap), size.height - barHeight),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(1.dp.toPx(), 1.dp.toPx())
            )
        }
    }
}

@Composable
private fun rememberBatteryLevel(context: Context): Int {
    var level by remember { mutableStateOf(-1) }
    LaunchedEffect(Unit) {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawLevel = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        level = if (rawLevel >= 0 && scale > 0) (rawLevel * 100 / scale) else -1
    }
    return level
}

@Composable
private fun BatteryGlyph(percent: Int) {
    val fillFraction = (percent.coerceIn(0, 100) / 100f)
    Box(
        modifier = Modifier
            .width(22.dp)
            .height(11.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0x33FFFFFF))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(if (percent >= 0) fillFraction else 1f)
                .background(
                    if (percent in 0..15) Color(0xFFFF5E5E) else Color(0xFFF5F2FF)
                )
        )
    }
}

@Composable
private fun ClockBlock(use24Hour: Boolean) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }
    val timeFmt = remember(use24Hour) {
        SimpleDateFormat(if (use24Hour) "HH:mm" else "h:mm", Locale.getDefault())
    }
    val dateFmt = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()) }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(500)) + slideInVertically(
            animationSpec = tween(500),
            initialOffsetY = { -it / 3 }
        )
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = timeFmt.format(now),
                color = Color(0xFFF5F2FF),
                fontSize = 68.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = dateFmt.format(now),
                color = Color(0xFFB8AED6),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(16.dp))
            Surface(shape = RoundedCornerShape(50), color = Color(0x1AFFFFFF)) {
                Text(
                    text = "  SzutyiUI  ",
                    modifier = Modifier.padding(vertical = 7.dp),
                    color = Color(0xFFF5F2FF),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun AppIconButton(
    app: AppInfo,
    size: Int = 56,
    showLabel: Boolean = false,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "iconScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .padding(4.dp)
            .pointerInput(app.packageName) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onTap(app) },
                    onLongPress = { onLongPress(app) }
                )
            }
    ) {
        val bitmap = remember(app.packageName) {
            app.icon.toBitmap(width = 144, height = 144).asImageBitmap()
        }
        Image(
            bitmap = bitmap,
            contentDescription = app.label,
            modifier = Modifier
                .size(size.dp)
                .scale(scale)
                .clip(RoundedCornerShape(18.dp))
        )
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = app.label,
                color = Color(0xFFB8AED6),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun FolderRow(
    folders: List<Folder>,
    appsFor: (Folder) -> List<AppInfo>,
    onOpen: (Folder) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        folders.forEach { folder ->
            FolderChip(folder = folder, apps = appsFor(folder), onTap = { onOpen(folder) })
        }
    }
}

@Composable
private fun FolderChip(folder: Folder, apps: List<AppInfo>, onTap: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(64.dp)
            .pointerInput(folder.id) {
                detectTapGestures(onTap = { onTap() })
            }
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color(0x26FFFFFF),
            modifier = Modifier.size(56.dp)
        ) {
            if (apps.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("+", color = Color(0xFFB8AED6), fontSize = 20.sp)
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    for (row in 0 until 2) {
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            for (col in 0 until 2) {
                                val app = apps.getOrNull(row * 2 + col)
                                if (app != null) {
                                    val bitmap = remember(app.packageName) {
                                        app.icon.toBitmap(width = 96, height = 96).asImageBitmap()
                                    }
                                    Image(
                                        bitmap = bitmap,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(4.dp))
                                    )
                                } else {
                                    Spacer(Modifier.weight(1f).fillMaxHeight())
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = folder.name,
            color = Color(0xFFB8AED6),
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@Composable
private fun Dock(
    apps: List<AppInfo>,
    showLabels: Boolean,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = Color(0x1FFFFFFF),
        shadowElevation = 12.dp,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            apps.forEach { app ->
                AppIconButton(app = app, showLabel = showLabels, onTap = onTap, onLongPress = onLongPress)
            }
        }
    }
}

@Composable
private fun SwipeHandle(accentColor: Color) {
    val infiniteTransition = rememberInfiniteTransition(label = "swipeHint")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "handleAlpha"
    )
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .width(120.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(50))
                .background(accentColor.copy(alpha = alpha))
        )
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, accentColor: Color) {
    var focused by remember { mutableStateOf(false) }
    val borderAlpha by animateFloatAsState(if (focused) 0.6f else 0f, label = "searchBorder")

    Surface(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(50),
        color = Color(0x1AFFFFFF),
        border = BorderStroke(1.dp, accentColor.copy(alpha = borderAlpha))
    ) {
        Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                cursorBrush = SolidColor(accentColor),
                modifier = Modifier.onFocusChanged { focused = it.isFocused },
                decorationBox = { innerField ->
                    if (value.isEmpty()) {
                        Text("Search apps", color = Color(0xFF7A6F99), fontSize = 14.sp)
                    }
                    innerField()
                }
            )
        }
    }
}

@Composable
private fun AppGrid(
    apps: List<AppInfo>,
    onTap: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = modifier.padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(apps, key = { it.packageName }) { app ->
            AppIconButton(app = app, showLabel = true, onTap = onTap, onLongPress = onLongPress)
        }
    }
}

@Composable
private fun AppContextMenu(
    app: AppInfo,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(app.label) },
        text = { Text("Choose an action for this app.") },
        confirmButton = {
            TextButton(onClick = onInfo) { Text("App info") }
        },
        dismissButton = {
            TextButton(onClick = onUninstall) { Text("Uninstall") }
        }
    )
}

@Composable
private fun SettingsOverlay(
    accentIndex: Int,
    onAccentChange: (Int) -> Unit,
    use24Hour: Boolean,
    onUse24HourChange: (Boolean) -> Unit,
    showDockLabels: Boolean,
    onShowDockLabelsChange: (Boolean) -> Unit,
    onEditDock: () -> Unit,
    folders: List<Folder>,
    onNewFolder: () -> Unit,
    onEditFolder: (Folder) -> Unit,
    onDeleteFolder: (Folder) -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onDismiss() })
            }
    ) {
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .heightIn(max = 480.dp)
                .padding(16.dp)
                .pointerInput(Unit) { detectTapGestures(onTap = { /* swallow: don't let it reach the scrim behind */ }) },
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF1C1330),
            shadowElevation = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    "SzutyiUI Settings",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(20.dp))

                Text(
                    "ACCENT COLOR",
                    color = Color(0xFFB8AED6),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    ACCENTS.forEachIndexed { index, accent ->
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(accent.color)
                                .then(
                                    if (index == accentIndex)
                                        Modifier.border(3.dp, Color.White, CircleShape)
                                    else Modifier
                                )
                                .pointerInput(index) {
                                    detectTapGestures(onTap = { onAccentChange(index) })
                                }
                        )
                    }
                }

                Spacer(Modifier.height(24.dp))
                SettingRow(label = "24-hour clock", checked = use24Hour, onCheckedChange = onUse24HourChange)
                Spacer(Modifier.height(14.dp))
                SettingRow(
                    label = "Show labels in dock",
                    checked = showDockLabels,
                    onCheckedChange = onShowDockLabelsChange
                )

                Spacer(Modifier.height(22.dp))
                Surface(
                    onClick = onEditDock,
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0x1AFFFFFF),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Choose dock apps", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("\u203A", color = Color(0xFFB8AED6))
                    }
                }

                Spacer(Modifier.height(24.dp))
                Text(
                    "FOLDERS",
                    color = Color(0xFFB8AED6),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))
                folders.forEach { folder ->
                    Surface(
                        onClick = { onEditFolder(folder) },
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0x1AFFFFFF),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(folder.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${folder.packages.size} app${if (folder.packages.size == 1) "" else "s"}",
                                    color = Color(0xFFB8AED6),
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = "\u2715",
                                color = Color(0xFFB8AED6),
                                fontSize = 14.sp,
                                modifier = Modifier.pointerInput(folder.id) {
                                    detectTapGestures(onTap = { onDeleteFolder(folder) })
                                }
                            )
                        }
                    }
                }
                Surface(
                    onClick = onNewFolder,
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0x1AFFFFFF),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("+ Create folder", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DockPickerOverlay(
    allApps: List<AppInfo>,
    selected: List<String>,
    accentColor: Color,
    onToggle: (String) -> Unit,
    onDone: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0712))
    ) {
        Spacer(Modifier.height(48.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Choose dock apps", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "${selected.size}/5 selected",
                    color = Color(0xFFB8AED6),
                    fontSize = 12.sp
                )
            }
            TextButton(onClick = onDone) {
                Text("Done", color = accentColor, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(allApps, key = { it.packageName }) { app ->
                val isSelected = selected.contains(app.packageName)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(4.dp)
                        .pointerInput(app.packageName) {
                            detectTapGestures(onTap = { onToggle(app.packageName) })
                        }
                ) {
                    val bitmap = remember(app.packageName) {
                        app.icon.toBitmap(width = 144, height = 144).asImageBitmap()
                    }
                    Image(
                        bitmap = bitmap,
                        contentDescription = app.label,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .then(
                                if (isSelected)
                                    Modifier.border(3.dp, accentColor, RoundedCornerShape(18.dp))
                                else Modifier
                            )
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = app.label,
                        color = Color(0xFFB8AED6),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun FolderContentsOverlay(
    folder: Folder,
    apps: List<AppInfo>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onTapApp: (AppInfo) -> Unit,
    onLongPressApp: (AppInfo) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0712))
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount > 14) onDismiss()
                }
            }
    ) {
        Spacer(Modifier.height(48.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(folder.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                TextButton(onClick = onEdit) {
                    Text("Edit", color = Color(0xFFB8AED6), fontWeight = FontWeight.SemiBold)
                }
                TextButton(onClick = onDismiss) {
                    Text("Close", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (apps.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No apps in this folder yet.", color = Color(0xFFB8AED6), fontSize = 13.sp)
            }
        } else {
            AppGrid(
                apps = apps,
                onTap = onTapApp,
                onLongPress = onLongPressApp,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun FolderEditorOverlay(
    allApps: List<AppInfo>,
    editingFolder: Folder?,
    accentColor: Color,
    onSave: (name: String, packages: List<String>) -> Unit,
    onDelete: (() -> Unit)?,
    onCancel: () -> Unit
) {
    var name by remember(editingFolder) { mutableStateOf(editingFolder?.name ?: "") }
    var selected by remember(editingFolder) {
        mutableStateOf(editingFolder?.packages ?: emptyList())
    }
    val canSave = name.isNotBlank() && selected.isNotEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0712))
    ) {
        Spacer(Modifier.height(48.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onCancel) {
                Text("Cancel", color = Color(0xFFB8AED6), fontWeight = FontWeight.SemiBold)
            }
            Text(
                if (editingFolder == null) "New folder" else "Edit folder",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            TextButton(onClick = { if (canSave) onSave(name.trim(), selected) }, enabled = canSave) {
                Text(
                    "Save",
                    color = if (canSave) accentColor else Color(0xFF4A4460),
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Surface(
            modifier = Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(50),
            color = Color(0x1AFFFFFF)
        ) {
            Box(modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                BasicTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    cursorBrush = SolidColor(accentColor),
                    decorationBox = { innerField ->
                        if (name.isEmpty()) {
                            Text("Folder name", color = Color(0xFF7A6F99), fontSize = 14.sp)
                        }
                        innerField()
                    }
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "${selected.size} selected \u2014 tap apps to add or remove",
            color = Color(0xFFB8AED6),
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 20.dp)
        )
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(allApps, key = { it.packageName }) { app ->
                val isSelected = selected.contains(app.packageName)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(4.dp)
                        .pointerInput(app.packageName) {
                            detectTapGestures(onTap = {
                                selected = if (isSelected) selected - app.packageName
                                else selected + app.packageName
                            })
                        }
                ) {
                    val bitmap = remember(app.packageName) {
                        app.icon.toBitmap(width = 144, height = 144).asImageBitmap()
                    }
                    Image(
                        bitmap = bitmap,
                        contentDescription = app.label,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .then(
                                if (isSelected)
                                    Modifier.border(3.dp, accentColor, RoundedCornerShape(18.dp))
                                else Modifier
                            )
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = app.label,
                        color = Color(0xFFB8AED6),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
        }
        if (onDelete != null) {
            Surface(
                onClick = onDelete,
                shape = RoundedCornerShape(16.dp),
                color = Color(0x33FF5E5E),
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(14.dp), contentAlignment = Alignment.Center) {
                    Text("Delete folder", color = Color(0xFFFF8A8A), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
