package com.szutyi.launcher

import android.content.Context
import androidx.compose.ui.graphics.Color

/** One accent color option, shown as a swatch in the settings panel. */
data class Accent(val color: Color, val label: String)

val ACCENTS = listOf(
    Accent(Color(0xFF3DDAD7), "Teal"),
    Accent(Color(0xFFFF8A3D), "Orange"),
    Accent(Color(0xFFFF5EA8), "Pink"),
    Accent(Color(0xFF7A8BFF), "Indigo")
)

/**
 * One wallpaper preset: the radial-gradient base plus the two ambient glow
 * blobs drawn on top of it. Picked in Settings, previewed as a small swatch.
 */
data class WallpaperPreset(
    val label: String,
    val gradient: List<Color>,
    val blobTopStart: Color,
    val blobBottomEnd: Color
)

val WALLPAPERS = listOf(
    WallpaperPreset(
        label = "Nebula",
        gradient = listOf(Color(0xFF2A1F4D), Color(0xFF14233A), Color(0xFF0D0916)),
        blobTopStart = Color(0xFF7A8BFF),
        blobBottomEnd = Color(0xFFFF5EA8)
    ),
    WallpaperPreset(
        label = "Midnight",
        gradient = listOf(Color(0xFF101820), Color(0xFF0C1420), Color(0xFF07090F)),
        blobTopStart = Color(0xFF3DDAD7),
        blobBottomEnd = Color(0xFF2E4A7A)
    ),
    WallpaperPreset(
        label = "Sunset",
        gradient = listOf(Color(0xFF3D1F2A), Color(0xFF2A1730), Color(0xFF150C20)),
        blobTopStart = Color(0xFFFF8A3D),
        blobBottomEnd = Color(0xFFFF5EA8)
    ),
    WallpaperPreset(
        label = "Forest",
        gradient = listOf(Color(0xFF16302A), Color(0xFF10201F), Color(0xFF0A1412)),
        blobTopStart = Color(0xFF3DDAD7),
        blobBottomEnd = Color(0xFF4DFF8A)
    ),
    WallpaperPreset(
        label = "Mono",
        gradient = listOf(Color(0xFF232323), Color(0xFF171717), Color(0xFF0D0D0D)),
        blobTopStart = Color(0xFF7A7A7A),
        blobBottomEnd = Color(0xFF3D3D3D)
    )
)

/** How the app drawer (and dock/home pickers) order the app list. */
enum class AppSortOrder(val label: String) {
    NAME_ASC("A \u2192 Z"),
    NAME_DESC("Z \u2192 A"),
    RECENTLY_INSTALLED("Newest first")
}

/**
 * Thin SharedPreferences wrapper for everything the settings panel controls.
 * Kept as simple get/set pairs rather than a DataStore to avoid an extra
 * dependency for a handful of small values.
 */
object SettingsRepository {
    private const val PREFS = "szutyi_settings"
    private const val KEY_ACCENT = "accent_index"
    private const val KEY_24H = "use_24h"
    private const val KEY_DOCK_LABELS = "show_dock_labels"
    private const val KEY_DOCK_APPS = "dock_apps"
    private const val KEY_WALLPAPER = "wallpaper_index"
    private const val KEY_SORT_ORDER = "app_sort_order"
    private const val KEY_HOME_APPS = "home_apps"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAccentIndex(context: Context): Int =
        prefs(context).getInt(KEY_ACCENT, 0).coerceIn(0, ACCENTS.lastIndex)

    fun setAccentIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_ACCENT, index).apply()
    }

    fun getUse24Hour(context: Context): Boolean =
        prefs(context).getBoolean(KEY_24H, false)

    fun setUse24Hour(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_24H, value).apply()
    }

    fun getShowDockLabels(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DOCK_LABELS, false)

    fun setShowDockLabels(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_DOCK_LABELS, value).apply()
    }

    /** Empty list means "no custom dock chosen yet" - caller falls back to defaults. */
    fun getDockPackages(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_DOCK_APPS, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(",")
    }

    fun setDockPackages(context: Context, packages: List<String>) {
        prefs(context).edit().putString(KEY_DOCK_APPS, packages.joinToString(",")).apply()
    }

    fun getWallpaperIndex(context: Context): Int =
        prefs(context).getInt(KEY_WALLPAPER, 0).coerceIn(0, WALLPAPERS.lastIndex)

    fun setWallpaperIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_WALLPAPER, index).apply()
    }

    fun getSortOrder(context: Context): AppSortOrder {
        val name = prefs(context).getString(KEY_SORT_ORDER, AppSortOrder.NAME_ASC.name)
        return runCatching { AppSortOrder.valueOf(name ?: AppSortOrder.NAME_ASC.name) }
            .getOrDefault(AppSortOrder.NAME_ASC)
    }

    fun setSortOrder(context: Context, order: AppSortOrder) {
        prefs(context).edit().putString(KEY_SORT_ORDER, order.name).apply()
    }

    /** Empty list means "no home-screen icons pinned yet". */
    fun getHomeApps(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_HOME_APPS, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(",")
    }

    fun setHomeApps(context: Context, packages: List<String>) {
        prefs(context).edit().putString(KEY_HOME_APPS, packages.joinToString(",")).apply()
    }
}
