package com.szutyi.launcher

import android.content.Context
import androidx.compose.ui.graphics.Color

/** One accent color option, shown as a swatch in the settings panel. */
data class Accent(val color: Color, val label: String)

val ACCENTS = listOf(
    Accent(Color(0xFF3DDAD7), "Teal"),
    Accent(Color(0xFFFF8A3D), "Orange"),
    Accent(Color(0xFFFF5EA8), "Pink"),
    Accent(Color(0xFF7A8BFF), "Indigo")
)

/** A user-created group of apps, shown as one icon on the home screen. */
data class Folder(val id: String, val name: String, val packages: List<String>)

/**
 * Thin SharedPreferences wrapper for everything the settings panel controls.
 * Kept as simple get/set pairs rather than a DataStore to avoid an extra
 * dependency for a handful of small values.
 */
object SettingsRepository {
    private const val PREFS = "szutyi_settings"
    private const val KEY_ACCENT = "accent_index"
    private const val KEY_24H = "use_24h"
    private const val KEY_DOCK_LABELS = "show_dock_labels"
    private const val KEY_DOCK_APPS = "dock_apps"
    private const val KEY_FOLDERS = "folders"
    // Non-printable separators: safe even if a folder name contains commas.
    private const val FIELD_SEP = "\u001F"
    private const val RECORD_SEP = "\u001E"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAccentIndex(context: Context): Int =
        prefs(context).getInt(KEY_ACCENT, 0).coerceIn(0, ACCENTS.lastIndex)

    fun setAccentIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_ACCENT, index).apply()
    }

    fun getUse24Hour(context: Context): Boolean =
        prefs(context).getBoolean(KEY_24H, false)

    fun setUse24Hour(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_24H, value).apply()
    }

    fun getShowDockLabels(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DOCK_LABELS, false)

    fun setShowDockLabels(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_DOCK_LABELS, value).apply()
    }

    /** Empty list means "no custom dock chosen yet" - caller falls back to defaults. */
    fun getDockPackages(context: Context): List<String> {
        val raw = prefs(context).getString(KEY_DOCK_APPS, "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(",")
    }

    fun setDockPackages(context: Context, packages: List<String>) {
        prefs(context).edit().putString(KEY_DOCK_APPS, packages.joinToString(",")).apply()
    }

    fun getFolders(context: Context): List<Folder> {
        val raw = prefs(context).getString(KEY_FOLDERS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(RECORD_SEP).mapNotNull { record ->
            val parts = record.split(FIELD_SEP)
            if (parts.size < 2) return@mapNotNull null
            val (id, name) = parts[0] to parts[1]
            val packages = if (parts.size > 2 && parts[2].isNotBlank()) parts[2].split(",") else emptyList()
            Folder(id = id, name = name, packages = packages)
        }
    }

    fun setFolders(context: Context, folders: List<Folder>) {
        val raw = folders.joinToString(RECORD_SEP) { folder ->
            listOf(folder.id, folder.name, folder.packages.joinToString(",")).joinToString(FIELD_SEP)
        }
        prefs(context).edit().putString(KEY_FOLDERS, raw).apply()
    }
}
