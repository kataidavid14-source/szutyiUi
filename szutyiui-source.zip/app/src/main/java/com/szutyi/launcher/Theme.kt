package com.szutyi.launcher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SzutyiColors = darkColorScheme(
    primary = Color(0xFFFF8A3D),
    secondary = Color(0xFF3DDAD7),
    tertiary = Color(0xFFFF5EA8),
    background = Color(0xFF120C1E),
    surface = Color(0xFF1C1330)
)

@Composable
fun SzutyiLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SzutyiColors,
        content = content
    )
}
